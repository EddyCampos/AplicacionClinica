﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CapaEntidades;
using CapaLogica;
using System.Data;
using System.Text.RegularExpressions;

namespace SitioWeb
{
    public partial class AgregarCita : System.Web.UI.Page
    {
        //Variable global del mensaje
        string mensajeScript = string.Empty;

        /// <summary>
        /// Cuando carga la pagina muestra los datos del paciente
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            EntidadPacientes paciente;
            BLPacientes logica = new BLPacientes(clsConfiguracion.getConnectionString);
            int id;

            cboMedicos.AutoPostBack = true;
            cboEspecialidad.AutoPostBack = true;
            TxtHora.AutoPostBack = true;
            TxtIdPaciente.Visible = false;

            if (string.IsNullOrEmpty(TxtHora.Text) &&
                string.IsNullOrEmpty(TxtMotivo.Text))
            {
                BtnGuardar.Enabled = false;
            }
            else
            {
                BtnGuardar.Enabled = true;
            }

            try
            {
                if (!Page.IsPostBack)//Cuando carga la pagina
                {
                    cboMedicos.Enabled = false;

                    if (Session["IdPaciente"] != null)//Obtiene el ID del otro Form
                    {
                        id = int.Parse(Session["IdPaciente"].ToString());
                        paciente = logica.ObtenerPaciente(id);
                                           
                        if (paciente.Existe)
                        {
                            TxtNombre.Text = $"{paciente.Nombre.ToString()} {paciente.Apellido01.ToString()} {paciente.Apellido02.ToString()}";
                            TxtCedula.Text = paciente.NumCedula;
                            TxtIdPaciente.Text = paciente.IdPaciente.ToString();                   

                        }
                        else
                        {
                            mensajeScript = string.Format("javascript:mostrarMensaje('Paciente no encontrado')");
                            //Carga el JS
                            ScriptManager.RegisterStartupScript(this, typeof(string), "MensajeRetorno", mensajeScript, true);
                        }
                        
                    }

                }//Page.IsPostBack
            }
            catch (Exception ex)
            {
                mensajeScript = string.Format("javascript:mostrarMensaje('{0}')", ex.Message);
                //Carga el JS
                ScriptManager.RegisterStartupScript(this, typeof(string), "MensajeRetorno", mensajeScript, true);
                Response.Redirect("Clientes.aspx");
            }
        }

        /// <summary>
        /// Genera la entidad del paciente
        /// </summary>
        /// <returns></returns>
        private EntidadPacientes GenerarEntidadPaciente()
        {
            EntidadPacientes paciente = new EntidadPacientes();

            paciente.SetNombre(TxtNombre.Text);
            paciente.SetApellido01(TxtNombre.Text);
            paciente.SetApellido02(TxtNombre.Text);
            paciente.SetNumCedula(TxtCedula.Text);

            return paciente;
        }

        /// <summary>
        /// Obtiene el nombre de los medicos y los coloca en el dropdown list para seleccionar 
        /// </summary>
        private void ObtenerNombres(string condicion = "")
        {
            DataSet DsNombresMedicos;
            BLEmpleados logica = new BLEmpleados(clsConfiguracion.getConnectionString);

            // Crea una lista para almacenar los objetos
            List<NombreMedico> listaObjetos = new List<NombreMedico>();

            try
            {
                condicion = cboEspecialidad.SelectedValue;
                DsNombresMedicos = logica.ObtenerNombres(condicion);
                string nombre = DsNombresMedicos.ToString();

                // Recorre las filas del DataSet y crea objetos para cada fila
                foreach (DataRow row in DsNombresMedicos.Tables["EMPLEADOS"].Rows)
                {
                    NombreMedico objeto = new NombreMedico
                    {
                        Id = Convert.ToInt32(row["ID_MEDICO"]),
                        Nombre = row["NOMBRE"].ToString(),
                        Apellido1 = row["APELLIDO_01"].ToString(),
                        Apellido2 = row["APELLIDO_02"].ToString()

                    };

                    listaObjetos.Add(objeto);//Los guarda en la lista
                }

                //Verifica si la lista está vacia
                if (listaObjetos.Count >= 1)
                {
                    //Si hay medicos
                    cboMedicos.Items.Clear();//Limpia todos los items
                    foreach (var item in listaObjetos)
                    {
                        cboMedicos.Items.Add($"{item.Nombre} {item.Apellido1} {item.Apellido2}");
                    }
                }
                else
                {
                    //No hay medicos
                    cboMedicos.Items.Clear();
                    cboMedicos.Items.Add("No hay médicos");
                }

                //Envia la lista por un session
                Session["DatosMedicos"] = listaObjetos;
            }
            catch (Exception)
            {

                throw;
            }
        }

        /// <summary>
        /// Clase utilizada para guardar los nombres de los médicos obtenidos
        /// </summary>
        public class NombreMedico
        {
            public int Id { get; set; }
            public string Nombre { get; set; }
            public string Apellido1 { get; set; }
            public string Apellido2 { get; set; }
            public string DiasSemana { get; set; }
            public TimeSpan H_Entrada { get; set; }
            public TimeSpan H_Salida { get; set; }
        }

        /// <summary>
        /// 
        /// </summary>
        public class CitasMedico
        {
            public int Id { get; set; }
            public DateTime Dia { get; set; }
            public TimeSpan Hora { get; set; }
        }

        /// <summary>
        /// Llama al metódo que obtiene los medicos cada vez que se selecciona un item diferente
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void cboEspecialidad_SelectedIndexChanged(object sender, EventArgs e)
        {

            if (cboEspecialidad.SelectedValue == "nulo")
            {
                cboMedicos.Enabled = false;
            }
            else
            {
                cboMedicos.Enabled = true;
            }

            ObtenerNombres();
            ObtenerAgendaMedico();
            //cboMedicos.SelectedIndex =0;
            
        }

        /// <summary>
        /// Obtiene los dias laborales de los medicos junto con la hora de entrada y salida, los guarda en el list 
        /// </summary>
        private void ObtenerAgendaMedico(int condicion = 0)
        {
            DataSet DsAgendaMedicos;
            BLAgendas logica = new BLAgendas(clsConfiguracion.getConnectionString);
            NombreMedico medico = new NombreMedico();
            int indice = 0;
            int id = 0;

            // Crea una lista para almacenar los objetos
            List<NombreMedico> listaObjetos = new List<NombreMedico>();

            //Recibe la lista por un session
            listaObjetos = (List<NombreMedico>)Session["DatosMedicos"];

            indice = cboMedicos.SelectedIndex;

            try
            {
                if (Session["DatosMedicos"] != null)
                {
                    medico = listaObjetos[indice];
                    id = medico.Id;

                    DsAgendaMedicos = logica.ObtenerAgendaMedico(id);

                    // Recorre las filas del DataSet y crea objetos para cada fila
                    foreach (DataRow row in DsAgendaMedicos.Tables["AGENDA"].Rows)
                    {
                        medico.DiasSemana = row["DIAS_SEMANA"].ToString();
                        medico.H_Entrada = TimeSpan.Parse(row["HORA_ENTRADA"].ToString());
                        medico.H_Salida = TimeSpan.Parse(row["HORA_SALIDA"].ToString());
                    }
                }
                else
                {
                    cboMedicos.Focus();
                }
            }
            catch (Exception)
            {

                throw;
            }
 
        }

        /// <summary>
        /// Llama al metódo que obtiene la agenda cada vez que se selecciona un item diferente
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void cboDias_SelectedIndexChanged(object sender, EventArgs e)
        {
            //ObtenerAgendaMedico();
            //***********************************************************************
        }

        /// <summary>
        /// Realiza las validaciones de la fecha para agendar las citas
        /// </summary>
        private void FechaSeleccionada()
        {
            DateTime fecha;
            DateTime fechaAnticipacion;
            fecha = dtpFecha.SelectedDate;
            fechaAnticipacion = DateTime.Now.AddDays(2);

            try
            {
                //Verifica que el dia no sea sabado o domingo
                if (Convert.ToInt32(fecha.DayOfWeek) == 6 || Convert.ToInt32(fecha.DayOfWeek) == 0)
                {
                    //Mensaje
                    mensajeScript = string.Format("javascript:mostrarMensaje('El horario de la Clínica es de Lunes a Viernes')");
                    //Carga el JS
                    ScriptManager.RegisterStartupScript(this, typeof(string), "MensajeRetorno", mensajeScript, true);

                    if (Convert.ToInt32(fecha.DayOfWeek) == 6)
                    {
                        dtpFecha.SelectedDate = fecha.AddDays(-1);
                    }
                    else if (Convert.ToInt32(fecha.DayOfWeek) == 0)
                    {
                        dtpFecha.SelectedDate = fecha.AddDays(-2);
                    }
                }

                //Verifica que tenga dos dias de anticipacion
                if (fecha < fechaAnticipacion)
                {
                    //Mensaje
                    mensajeScript = string.Format("javascript:mostrarMensaje('La fecha de la cita debe tener dos días de anticipación')");
                    //Carga el JS
                    ScriptManager.RegisterStartupScript(this, typeof(string), "MensajeRetorno", mensajeScript, true);

                    dtpFecha.SelectedDate = DateTime.Now;
                }
            }
            catch (Exception)
            {

                throw;
            }

        }

        /// <summary>
        /// Realiza las validaciones de la hora para agendar las citas
        /// </summary>
        private void HoraSeleccionada()
        {
            DateTime hora = Convert.ToDateTime(TxtHora.Text);
            int minutos = 0;
            int minutosRestantes = 0;

            minutos = hora.Minute;

            try
            {

                if (hora < Convert.ToDateTime("7:00") || hora >= Convert.ToDateTime("17:00"))
                {
                   
                    //Mensaje
                    mensajeScript = string.Format("javascript:mostrarMensaje('El horario de la Clinica es de 7:00 am a 17:00 pm')");
                    //Carga el JS
                    ScriptManager.RegisterStartupScript(this, typeof(string), "MensajeRetorno", mensajeScript, true);
                    hora = Convert.ToDateTime("7:00");
                    TxtHora.Text = hora.ToString("HH:mm");
                }

                //Esta es la hora máxima en la que puede haber una cita
                if (hora >= Convert.ToDateTime("16:30"))
                {
                    //Mensaje
                    mensajeScript = string.Format("javascript:mostrarMensaje('Por el horario de la clinica la hora máxima para una cita es a las 16:30')");
                    //Carga el JS
                    ScriptManager.RegisterStartupScript(this, typeof(string), "MensajeRetorno", mensajeScript, true);

                    hora = Convert.ToDateTime("16:30");
                    TxtHora.Text = hora.ToString("HH:mm");

                }
                else if (minutos == 30 || minutos == 0) 
                {
                    TxtHora.Text = hora.ToString("HH:mm");
                }
                else if (minutos < 30)//Redondea la hora en intervalos de 30 minutos para abajo
                {
                    hora = hora.AddMinutes(-minutos);
                    TxtHora.Text = hora.ToString("HH:mm");

                    //Mensaje
                    mensajeScript = string.Format("javascript:mostrarMensaje('La hora se redondeo hacia abajo')");
                    //Carga el JS
                    ScriptManager.RegisterStartupScript(this, typeof(string), "MensajeRetorno", mensajeScript, true);
                }
                else if (minutos > 30)//Redondea la hora en intervalos de 30 minutos para arriba
                {
                    minutosRestantes = 60 - minutos;
                    hora = hora.AddMinutes(+minutosRestantes);
                    TxtHora.Text = hora.ToString("HH:mm");

                    //Mensaje
                    mensajeScript = string.Format("javascript:mostrarMensaje('La hora se redondeo hacia arriba')");
                    //Carga el JS
                    ScriptManager.RegisterStartupScript(this, typeof(string), "MensajeRetorno", mensajeScript, true);
                }
                else if (hora == Convert.ToDateTime("12:00") || hora == Convert.ToDateTime("12:30"))
                {
                    //Mensaje
                    mensajeScript = string.Format("javascript:mostrarMensaje('De 12:00 a 13:00 no es posible asignar citas')");
                    //Carga el JS
                    ScriptManager.RegisterStartupScript(this, typeof(string), "MensajeRetorno", mensajeScript, true);
                    hora = Convert.ToDateTime("11:00");
                    TxtHora.Text = hora.ToString("HH:mm");
                }


            }
            catch (Exception ex)
            {
                //Mensaje
                mensajeScript = string.Format("javascript:mostrarMensaje('{0}')", ex);
                //Carga el JS
                ScriptManager.RegisterStartupScript(this, typeof(string), "MensajeRetorno", mensajeScript, true);
            }
            
        }

        /// <summary>
        /// Agenda la cita
        /// </summary>
        private void AgendarCita()
        {
            DataSet DsAgendaMedicos;
            BLAgendas logica = new BLAgendas(clsConfiguracion.getConnectionString);
            NombreMedico medico = new NombreMedico();

            int indice = 0;
            int idMedico = 0;
            TimeSpan horaSalida = TimeSpan.Zero;
            TimeSpan horaCita = TimeSpan.Zero;
            TimeSpan horaEntradaMedico = TimeSpan.Zero;
            TimeSpan horaSalidaMedico = TimeSpan.Zero;
            string diasMedico = "";
            int indiceDiaSemana = 0;
            string diaCita = string.Empty;


            // Crea una lista para almacenar los objetos
            List<NombreMedico> listaObjetos = new List<NombreMedico>();

            //Recibe la lista por un session
            listaObjetos = (List<NombreMedico>)Session["DatosMedicos"];
            if (!string.IsNullOrEmpty(cboEspecialidad.Text) &&
                !string.IsNullOrEmpty(cboMedicos.Text) &&
                !string.IsNullOrEmpty(dtpFecha.SelectedDate.ToString()) &&
                !string.IsNullOrEmpty(TxtHora.Text) &&
                !string.IsNullOrEmpty(TxtMotivo.Text))
            {
                indice = cboMedicos.SelectedIndex;
                medico = listaObjetos[indice];
                idMedico = medico.Id;
                horaCita = TimeSpan.Parse(TxtHora.Text);
                horaEntradaMedico = medico.H_Entrada;
                horaSalidaMedico = medico.H_Salida;
                diasMedico = medico.DiasSemana;
                indiceDiaSemana = Convert.ToInt32(dtpFecha.SelectedDate.DayOfWeek);

                horaSalidaMedico = horaSalidaMedico.Add(TimeSpan.FromMinutes(-30));
            }
            else
            {
                //Mensaje
                mensajeScript = string.Format("javascript:mostrarMensaje('Debe llenar primero todos los espacios')");
                //Carga el JS
                ScriptManager.RegisterStartupScript(this, typeof(string), "MensajeRetorno", mensajeScript, true);
            }

            try
            {
                if (horaCita < horaEntradaMedico || horaCita > horaSalidaMedico)
                {
                    //Mensaje
                    mensajeScript = string.Format("javascript:mostrarMensaje('El horario de la cita no coincide con el horario del médico seleccionado o no respetar los 30 minutos establecidos')");
                    //Carga el JS
                    ScriptManager.RegisterStartupScript(this, typeof(string), "MensajeRetorno", mensajeScript, true);
                }

                if (indiceDiaSemana == 1)
                {
                    diaCita = "L";
                }
                else if (indiceDiaSemana == 2)
                {
                    diaCita = "M";
                }
                else if (indiceDiaSemana == 3)
                {
                    diaCita = "K";
                }
                else if (indiceDiaSemana == 4)
                {
                    diaCita = "J";
                }
                else if (indiceDiaSemana == 5)
                {
                    diaCita = "V";
                }

                if (!diasMedico.Contains(diaCita))
                {
                    //Mensaje
                    mensajeScript = string.Format("javascript:mostrarMensaje('El Médico no trabaja ese dia')");
                    //Carga el JS
                    ScriptManager.RegisterStartupScript(this, typeof(string), "MensajeRetorno", mensajeScript, true);
                }



            }
            catch (Exception)
            {

                throw;
            }
            
        }


        /// <summary>
        /// Llama al metodo que hace las validaciones cada vez que se selecciona otra fecha
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void dtpFecha_SelectionChanged(object sender, EventArgs e)
        {
            FechaSeleccionada();
        }

        /// <summary>
        /// Llama al metodo que hace las validaciones cada vez que se escribe una hora
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void TxtHora_TextChanged(object sender, EventArgs e)
        {
            DateTime hora;
            string horaEvaluar = TxtHora.Text.ToString();
            
            //Expresion regular para verificar que la hora este escrita en el formato
            string expresionRegular = @"^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$";

            //Hace la comparacion entre la variable y la expresion
            bool correcto = Regex.IsMatch(horaEvaluar, expresionRegular);

            try
            {
                //Verifica que el formato sea correcto
                if (correcto)
                {
                    //Si coincide con el formato
                    TxtHora.Text = horaEvaluar.ToString();
                }
                else
                {
                    //No coincide con el formato           
                    TxtHora.Text = TxtHora.Text + ":00";

                }

                HoraSeleccionada();
                
            }
            catch (Exception ex)
            {
                //TxtHora.Text = "7:00";
                //Mensaje
                mensajeScript = string.Format("javascript:mostrarMensaje('{0}')", ex.Message);
                //Carga el JS
                ScriptManager.RegisterStartupScript(this, typeof(string), "MensajeRetorno", mensajeScript, true);
                
            }
            
        }

        /// <summary>
        /// Llama al metodo que trae el horairo cada vez que se selecciona otro medico
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void cboMedicos_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cboMedicos.SelectedValue == "nulo")
            {
                dtpFecha.Enabled = false;
            }
            else
            {
                dtpFecha.Enabled = true;
            }
            ObtenerAgendaMedico();
        }

        /// <summary>
        /// Llama al metodo que guarda la cita cuando se da click al boton
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void BtnGuardar_Click(object sender, EventArgs e)
        {
            AgendarCita();
            ObtenerListaConsultas();
            //Response.Redirect("Consultas.aspx");
            Limpiar();
        }

        private void Limpiar()
        {
            cboEspecialidad.SelectedIndex = 0;
            cboMedicos.SelectedIndex = 0;
            TxtHora.Text = string.Empty;
            TxtMotivo.Text = string.Empty;
        }

        /// <summary>
        /// Método que guarda las citas ya asignadas y verifica que no hayan a la misma hora
        /// </summary>
        private void ObtenerListaConsultas()
        {
            DataSet DsListaConsultas;
            BLConsultas logica = new BLConsultas(clsConfiguracion.getConnectionString);
            NombreMedico medico = new NombreMedico();
            CitasMedico citas = new CitasMedico();
            int indice = 0;
            int condicion = 0;
            bool hayChoque = false;

            // Crea una lista para almacenar los objetos
            List<NombreMedico> listaObjetos = new List<NombreMedico>();

            //Lista para almacenar el total de citas asignadas del medico
            List<CitasMedico> listaCitas = new List<CitasMedico>();

            //Recibe la lista por un session
            listaObjetos = (List<NombreMedico>)Session["DatosMedicos"];

            indice = cboMedicos.SelectedIndex;

            medico = listaObjetos[indice];

            condicion = medico.Id;

            try
            {
                DsListaConsultas = logica.ObtenerListaConsultas(condicion);

                // Recorre las filas del DataSet y crea objetos para cada fila
                foreach (DataRow row in DsListaConsultas.Tables["CONSULTAS"].Rows)
                {
                    CitasMedico objeto = new CitasMedico
                    {
                        Id = Convert.ToInt32(row["ID_MEDICO"]),
                        Dia = Convert.ToDateTime(row["DIA"]),
                        Hora = TimeSpan.Parse(row["HORA"].ToString())

                    };

                    listaCitas.Add(objeto);//Los guarda en la lista
                }

                //Recorre el list y verifica si la fecha y hora es igual a alguna
                foreach (CitasMedico item in listaCitas)
                {
                    if ((item.Dia == Convert.ToDateTime(dtpFecha.SelectedDate)) && 
                        (item.Hora == TimeSpan.Parse(TxtHora.Text)))
                    {
                        hayChoque = true;
                        break;
                    }
                 
                }

                //Si hay un choque de horario
                if (hayChoque) 
                {
                    //Mensaje
                    mensajeScript = string.Format("javascript:mostrarMensaje('Ya existe una cita asignada a esa hora, puede seleccionar otro día u otra hora')");
                    //Carga el JS
                    ScriptManager.RegisterStartupScript(this, typeof(string), "MensajeRetorno", mensajeScript, true);
                }
                else
                {
                    //Guarda la cita
                    InsertarConsulta();
                }

            }
            catch (Exception)
            {

                throw;
            }
        }

        /// <summary>
        /// Genera la entidad para agregar la consulta
        /// </summary>
        /// <returns></returns>
        private EntidadConsultas GenerarEntidadConsultas()
        {
            EntidadConsultas consulta = new EntidadConsultas();
            NombreMedico medico = new NombreMedico();
            int indice = 0;
            int id = 0;

            // Crea una lista para almacenar los objetos
            List<NombreMedico> listaObjetos = new List<NombreMedico>();
            //Recibe la lista por un session
            listaObjetos = (List<NombreMedico>)Session["DatosMedicos"];

            indice = cboMedicos.SelectedIndex;

            medico = listaObjetos[indice];

            id = medico.Id;

            consulta.SetIdMedico(id);
            consulta.SetIdPaciente(Convert.ToInt32(TxtIdPaciente.Text));
            consulta.SetDia(dtpFecha.SelectedDate);
            consulta.SetHora(Convert.ToDateTime(TxtHora.Text));
            consulta.SetMotivo(TxtMotivo.Text);
            
            return consulta;

        }

        /// <summary>
        /// Inserta la consulta en la tabla de la BD
        /// </summary>
        private void InsertarConsulta()
        {
            EntidadConsultas consulta;
            BLConsultas logica = new BLConsultas(clsConfiguracion.getConnectionString);
            int resultado;

            try
            {
                if (!string.IsNullOrEmpty(cboEspecialidad.Text) &&
                    !string.IsNullOrEmpty(cboMedicos.Text) &&
                    !string.IsNullOrEmpty(dtpFecha.SelectedDate.ToString()) &&
                    !string.IsNullOrEmpty(TxtHora.Text) &&
                    !string.IsNullOrEmpty(TxtMotivo.Text))
                {
                    consulta = GenerarEntidadConsultas();
                    resultado = logica.InsertarConsulta(consulta);

                    //Mensaje
                    mensajeScript = string.Format("javascript:mostrarMensaje('Consulta agregada satisfactoriamente')");
                    //Carga el JS
                    ScriptManager.RegisterStartupScript(this, typeof(string), "MensajeRetorno", mensajeScript, true);

                }
                else
                {
                    //Mensaje
                    mensajeScript = string.Format("javascript:mostrarMensaje('Debe llenar primero todos los valores')");
                    //Carga el JS
                    ScriptManager.RegisterStartupScript(this, typeof(string), "MensajeRetorno", mensajeScript, true);
                }
            }
            catch (Exception)
            {

                throw;
            }
        }

        /// <summary>
        /// Redirige al formulario de pcientes
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void BtnCancelar_Click(object sender, EventArgs e)
        {
            Response.Redirect("Consultas.aspx");
        }
    }//Fin clase AgregarCita : System.Web.UI.Page
}//Fin namespace