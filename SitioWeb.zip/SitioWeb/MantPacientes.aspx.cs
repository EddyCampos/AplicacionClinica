﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CapaLogica;
using CapaEntidades;

namespace SitioWeb
{
    public partial class MantPacientes : System.Web.UI.Page
    {
        //Variable global del mensaje
        string mensajeScript = string.Empty;


        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            EntidadPacientes paciente;
            BLPacientes logica = new BLPacientes(clsConfiguracion.getConnectionString);
            int id = 0;

            try
            {
                if (!Page.IsPostBack)
                {
                    if (Session["IdActualizarPaciente"] != null)
                    {
                        id = Convert.ToInt32(Session["IdActualizarPaciente"].ToString());
                        paciente = logica.ObtenerPaciente(id);

                        if (paciente.Existe)
                        {
                            //Si el paciente existe
                            TxtId.Text = paciente.IdPaciente.ToString();
                            TxtCedula.Text = paciente.NumCedula.ToString();
                            TxtNombre.Text = paciente.Nombre;
                            TxtApellido1.Text = paciente.Apellido01;
                            TxtApellido2.Text = paciente.Apellido02;
                            TxtPais.Text = paciente.Pais;
                            CboProvincias.Text = paciente.Provincia;
                            CboSexo.Text = paciente.Sexo;
                            TxtFNacimiento.Text = paciente.FNacimiento.ToString();
                            CboEstadoCivil.Text = paciente.EstadoCivil;
                            TxtCorreo.Text = paciente.CorreoElectronico;
                            TxtTelefono.Text = paciente.NumTelefono.ToString();
                            CboTipoSangre.Text = paciente.TipoSangre;
                            CboEstado.Text = paciente.Estado;
                        }
                        else
                        {
                            //Mensaje
                            mensajeScript = string.Format("javascript:mostrarMensaje('El paciente no existe')");
                            //Carga el JS
                            ScriptManager.RegisterStartupScript(this, typeof(string), "MensajeRetorno", mensajeScript, true);
                        }
                    }//Session
                    else
                    {
                        TxtId.Text = "-1";
                        lblId.Visible = false;
                        TxtId.Visible = false;
                        TxtCedula.ReadOnly = false;
                    }
                }//!Page.IsPostBack
            }//Try
            catch (Exception ex)
            {
                //Mensaje
                mensajeScript = string.Format("javascript:mostrarMensaje('{0}')", ex.Message);
                //Carga el JS
                ScriptManager.RegisterStartupScript(this, typeof(string), "MensajeRetorno", mensajeScript, true);
                Response.Redirect("Pacientes.aspx");
            }
        }

        /// <summary>
        /// Guarda los datos cuando se le da click al boton
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void BtnGuardar_Click(object sender, EventArgs e)
        {
            EntidadPacientes paciente;
            BLPacientes logica = new BLPacientes(clsConfiguracion.getConnectionString);
            int resultado = 0;

            try
            {
                paciente = GeneraEntidadPacientes();

                if (paciente.Existe)
                {
                    //Modificar
                    resultado = logica.ModificarPacientes(paciente);
                }
                else
                {
                    //Insertar
                    resultado = logica.InsertarPaciente(paciente);
                }

                if (resultado > 0) 
                {
                    //Mensaje
                    mensajeScript = string.Format("javascript:mostrarMensaje('Operación exitosa')");
                    //Carga el JS
                    ScriptManager.RegisterStartupScript(this, typeof(string), "MensajeRetorno", mensajeScript, true);
                    Response.Redirect("Pacientes.aspx");
                }
                else
                {
                    //Mensaje
                    mensajeScript = string.Format("javascript:mostrarMensaje('No se pudo ejecutar la operación')");
                    //Carga el JS
                    ScriptManager.RegisterStartupScript(this, typeof(string), "MensajeRetorno", mensajeScript, true);
                }
            }
            catch (Exception ex)
            {
                mensajeScript = string.Format("javascript:mostrarMensaje('{0}')", ex);
                //Carga el JS
                ScriptManager.RegisterStartupScript(this, typeof(string), "MensajeRetorno", mensajeScript, true);
                Response.Redirect("Pacientes.aspx");
                throw;
            }
        }

        /// <summary>
        /// Genera la entidad del paciente
        /// </summary>
        /// <returns></returns>
        private EntidadPacientes GeneraEntidadPacientes()
        {
            EntidadPacientes pacientes = new EntidadPacientes();

            if (Session["IdActualizarPaciente"] != null)
            {
                //Modifica
                pacientes.IdPaciente = int.Parse(Session["IdActualizarPaciente"].ToString());
                pacientes.Existe = true;
            }
            else
            {
                pacientes.IdPaciente = -1;
                pacientes.Existe = false;
            }
            pacientes.IdPaciente = Convert.ToInt32(TxtId.Text);
            pacientes.NumCedula = TxtCedula.Text;
            pacientes.Nombre = TxtNombre.Text;
            pacientes.Apellido01 = TxtApellido1.Text;
            pacientes.Apellido02 = TxtApellido2.Text;
            pacientes.Pais = TxtPais.Text;
            pacientes.Provincia = CboProvincias.SelectedValue;
            pacientes.Sexo = CboSexo.SelectedValue;
            pacientes.FNacimiento = Convert.ToDateTime(TxtFNacimiento.Text);
            pacientes.EstadoCivil = CboEstadoCivil.SelectedValue;
            pacientes.CorreoElectronico = TxtCorreo.Text;
            pacientes.NumTelefono = TxtTelefono.Text;
            pacientes.TipoSangre = CboTipoSangre.Text;
            pacientes.Estado = CboEstado.SelectedValue;

            return pacientes;

        }

        /// <summary>
        /// Redirige a pacientes
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void BtnCancelar_Click(object sender, EventArgs e)
        {
            Response.Redirect("Pacientes.aspx");
        }
    }//Fin clase MantPacientes : System.Web.UI.Page
}//Fin namespace