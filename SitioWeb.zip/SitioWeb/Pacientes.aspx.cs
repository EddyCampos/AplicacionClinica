﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CapaEntidades;
using CapaLogica;

namespace SitioWeb
{
    public partial class Pacientes1 : System.Web.UI.Page
    {
        //Variable global del mensaje
        string mensajeScript = string.Empty;

        /// <summary>
        /// Cuando la pagina carga llama al metodo que muestra los pacientes
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!IsPostBack)
                {
                    CargarListaPacientes();
                }
            }
            catch (Exception ex)
            {
                mensajeScript = string.Format("javascript:mostrarMensaje('{0}')", ex.Message);
                //Carga el JS
                ScriptManager.RegisterStartupScript(this, typeof(string), "MensajeRetorno", mensajeScript, true);
            }
        }

        /// <summary>
        /// Carga la lista de clientes en el grid
        /// </summary>
        /// <param name="condicion"></param>
        /// <param name="orden"></param>
        public void CargarListaPacientes(string condicion = "", string orden = "")
        {
            BLPacientes logica = new BLPacientes(clsConfiguracion.getConnectionString);
            DataSet DSPacientes;

            try
            {
                DSPacientes = logica.ListarPacientes(condicion, orden);
                grdVistaPacientes.DataSource = DSPacientes;
                grdVistaPacientes.DataBind();
            }
            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void lnkEliminar_Command(object sender, CommandEventArgs e)
        {

        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void lnkEditar_Command(object sender, CommandEventArgs e)
        {
            Session["IdActualizarPaciente"] = e.CommandArgument.ToString();
            Response.Redirect("MantPacientes.aspx");        
        }

        /// <summary>
        /// Realiza una busqueda por nombre cuando se da click al boton
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void BtnBuscar_Click(object sender, EventArgs e)
        {
            string condicion = string.Empty;

            try
            {
                condicion = string.Format("NOMBRE LIKE '%{0}%'", TxtNombre.Text);
                CargarListaPacientes(condicion);
            }
            catch (Exception)
            {

                throw;
            }
        }

        /// <summary>
        /// Agrega un nuevo cliente cuando se da click al boton
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void BtnNuevo_Click(object sender, EventArgs e)
        {
            //Remueve la sesion
            Session.Remove("IdActualizarPaciente");

            Response.Redirect("MantPacientes.aspx");
        }
    }//Fin clase Pacientes1 : System.Web.UI.Page
}//Fin namespace