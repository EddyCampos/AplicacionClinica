﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using CapaEntidades;
using CapaLogica;

namespace SitioWeb
{
    public partial class Pacientes : System.Web.UI.Page
    {
        //Variable global del mensaje
        string mensajeScript = string.Empty;

        /// <summary>
        /// Carga la lista de clientes en el grid
        /// </summary>
        /// <param name="condicion"></param>
        /// <param name="orden"></param>
        public void CargarListaPacientes(string condicion = "", string orden = "")
        {
            BLPacientes logica = new BLPacientes(clsConfiguracion.getConnectionString);
            DataSet DSPacientes;

            try
            {
                DSPacientes = logica.ListarPacientes(condicion, orden);
                grdVistaPacientes.DataSource = DSPacientes;
                grdVistaPacientes.DataBind();
            }
            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>
        /// Carga en el grid los datos de la consultas
        /// </summary>
        public void CargarDatosConsultas()
        {
            DataSet dsDatosConsultas;
            BLConsultas logica = new BLConsultas(clsConfiguracion.getConnectionString);

            try
            {
                dsDatosConsultas = logica.ListarDatosConsultasCompletos();
                grdVistaConsultas.DataSource = dsDatosConsultas;
                grdVistaConsultas.DataBind();
            }
            catch (Exception)
            {

                throw;
            }
        }

        /// <summary>
        /// Cuando la pagina carga llama al metodo que muestra los pacientes
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!IsPostBack)
                {
                    PnlPacientes.Visible = false;
                    CargarListaPacientes();
                    CargarDatosConsultas();
                }
            }
            catch(Exception ex) {
                mensajeScript = string.Format("javascript:mostrarMensaje('{0}')", ex.Message);
                //Carga el JS
                ScriptManager.RegisterStartupScript(this, typeof(string), "MensajeRetorno", mensajeScript, true);
            }
        }

        /// <summary>
        /// Redirige al formulario donde se agrega la cita
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void lnkAgendar_Command(object sender, CommandEventArgs e)
        {
            Session["IdPaciente"] = e.CommandArgument.ToString();
            Response.Redirect("AgregarCita.aspx");
            //Response.Redirect("AgregarCita.aspx");
        }

        /// <summary>
        /// Muestra el panel y realiza la busqueda
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        protected void BtnBuscar_Click(object sender, EventArgs e)
        {
            PnlPacientes.Visible = true;

            string condicion = string.Empty;

            try
            {
                condicion = string.Format("NOMBRE LIKE '%{0}%'", TxtNombre.Text);
                CargarListaPacientes(condicion);
            }
            catch (Exception)
            {

                throw;
            }
        }
    }//Fin clase Pacientes : System.Web.UI.Page
}//Fin namespace