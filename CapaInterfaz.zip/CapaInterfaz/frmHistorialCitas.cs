﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using CapaEntidades;
using CapaLogica;

namespace CapaInterfaz
{
    public partial class frmHistorialCitas : Form
    {
        public frmHistorialCitas()
        {
            InitializeComponent();
        }

        //Cierra el formulario
        private void btnSalir_Click(object sender, EventArgs e)
        {
            Close();
        }//Fin btnSalir_Click

        //Generar Entidad
        private EntidadHistorialCitas GenerarEntidadCitas()
        {
            EntidadHistorialCitas historialCita = new EntidadHistorialCitas();

            historialCita.SetIdExpediente(Convert.ToInt32(txtIdExpediente.Text));
            historialCita.SetFecha(Convert.ToDateTime(dtpFecha.Value));
            historialCita.SetHora(Convert.ToDateTime(txtHora.Text));
            historialCita.SetIdMedicoResponsable(Convert.ToInt32(txtIdMedico.Text));
            historialCita.SetMotivo(txtMotivo.Text);

            return historialCita;
        }//Fin GenerarEntidadCitas
        
        //Guarda en la base de datos
        private void btnGuardarHistorial_Click(object sender, EventArgs e)
        {
            BLHistorialCitas logica = new BLHistorialCitas(Configuracion.getConnectionString);

            EntidadHistorialCitas historialCita;
            int resultado;

            try
            {
                if (!string.IsNullOrEmpty(txtIdExpediente.Text) &&
                    !string.IsNullOrEmpty(dtpFecha.Text) &&
                    !string.IsNullOrEmpty(txtHora.Text) &&
                    !string.IsNullOrEmpty(txtIdMedico.Text) &&
                    !string.IsNullOrEmpty(txtMotivo.Text))
                {
                    historialCita = GenerarEntidadCitas();
                    resultado = logica.InsertarHistorialCitas(historialCita);
                    MessageBox.Show("Cita insertada en el historial Correctamente", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    limpiar();
                    CargarListaHistorialCitas();
                }
                else
                {
                    MessageBox.Show("Datos obligatorios", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }//Fin btnGuardarHistorial_Click

        //Cargar la lista de clientes con un DATASET
        public void CargarListaHistorialCitas(string condicion = "", string orden = "")
        {
            BLHistorialCitas logica = new BLHistorialCitas(Configuracion.getConnectionString);
            DataSet DSHistorial;

            try
            {
                DSHistorial = logica.ListarHistorialCitas(condicion, orden);
                grdVistaHistorial.DataSource = DSHistorial;
                grdVistaHistorial.DataMember = DSHistorial.Tables["HISTORIAL_CITAS"].TableName;
            }
            catch (Exception)
            {

                MessageBox.Show("Ocurrió un error", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }//Fin CargarListaAgenda

        //Cuando carga el formulario que cargue la vista de la tabla
        private void frmHistorialCitas_Load(object sender, EventArgs e)
        {
            try
            {
                CargarListaHistorialCitas();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }//Fin frmHistorialCitas_Load

        //Limpia info de los espacios
        private void limpiar()
        {
            txtHistorialCita.Text = string.Empty;
            txtIdExpediente.Text = string.Empty;
            dtpFecha.Value = Convert.ToDateTime("01/01/1900");
            txtHora.Text = string.Empty;
            txtIdMedico.Text = string.Empty;
            txtMotivo.Text = string.Empty;
        }//Fin limpiar

        //Boton limpia todas las casillas
        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            limpiar();
        }//Fin btnLimpiar_Click

        //Cancela el evento cuando se ingresan letras o simbolos, valida solo numeros
        public void ValidarSoloNum(object sender, KeyPressEventArgs e)
        {
            if (char.IsDigit(e.KeyChar) || e.KeyChar == 8)//TECLAS: NUMEROS Y BORRAR
            {
                //NO SE CANCELA EL EVENTO
                e.Handled = false;
            }
            else
            {
                //CANCELA EL EVENTO
                e.Handled = true;
            }
        }//Fin ValidarSoloNum

        //Cancela el evento cuando se ingresan numeros o simbolos, valida solo letras
        private void ValidarSoloTxt(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar) || e.KeyChar == 8 || e.KeyChar == 32)//TECLAS: LETRAS Y BORRAR
            {
                //NO SE CANCELA EL EVENTO
                e.Handled = false;
            }
            else
            {
                //CANCELA EL EVENTO
                e.Handled = true;
            }
        }//Fin ValidarSoloTxt

        //Solo permite llenar el campo con numeros
        private void txtIdExpediente_KeyPress(object sender, KeyPressEventArgs e)
        {
            ValidarSoloNum(sender, e);
        }

        //Solo permite llenar el campo con numeros
        private void txtIdMedico_KeyPress(object sender, KeyPressEventArgs e)
        {
            ValidarSoloNum(sender, e);
        }

        //Solo permite llenar el campo con letras
        private void txtMotivo_KeyPress(object sender, KeyPressEventArgs e)
        {
            ValidarSoloTxt(sender, e);
        }
    }//Fin clase frmHistorialCitas : Form
}//Fin namespace
