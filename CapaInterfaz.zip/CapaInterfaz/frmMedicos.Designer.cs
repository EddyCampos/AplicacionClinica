﻿namespace CapaInterfaz
{
    partial class frmMedicos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtNumCerticado = new System.Windows.Forms.TextBox();
            this.txtIdEspecialidad = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtIdEmpleado = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnLimpiar = new System.Windows.Forms.Button();
            this.btnSalir = new System.Windows.Forms.Button();
            this.btnEliminar = new System.Windows.Forms.Button();
            this.grdVistaMedicos = new System.Windows.Forms.DataGridView();
            this.ID_SECRETARIO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idEmpleado = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.especialidad = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.numCertificacion = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnGuardarMedico = new System.Windows.Forms.Button();
            this.label13 = new System.Windows.Forms.Label();
            this.txtIdMedico = new System.Windows.Forms.TextBox();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdVistaMedicos)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.txtNumCerticado);
            this.groupBox2.Controls.Add(this.txtIdEspecialidad);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.txtIdEmpleado);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.btnLimpiar);
            this.groupBox2.Controls.Add(this.btnSalir);
            this.groupBox2.Controls.Add(this.btnEliminar);
            this.groupBox2.Controls.Add(this.grdVistaMedicos);
            this.groupBox2.Controls.Add(this.btnGuardarMedico);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.txtIdMedico);
            this.groupBox2.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.groupBox2.Location = new System.Drawing.Point(27, 24);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(827, 681);
            this.groupBox2.TabIndex = 40;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Médico";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(35, 266);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(233, 30);
            this.label3.TabIndex = 50;
            this.label3.Text = "Num Certificación";
            // 
            // txtNumCerticado
            // 
            this.txtNumCerticado.Location = new System.Drawing.Point(274, 259);
            this.txtNumCerticado.Name = "txtNumCerticado";
            this.txtNumCerticado.Size = new System.Drawing.Size(257, 37);
            this.txtNumCerticado.TabIndex = 49;
            // 
            // txtIdEspecialidad
            // 
            this.txtIdEspecialidad.Location = new System.Drawing.Point(274, 190);
            this.txtIdEspecialidad.Name = "txtIdEspecialidad";
            this.txtIdEspecialidad.Size = new System.Drawing.Size(257, 37);
            this.txtIdEspecialidad.TabIndex = 48;
            this.txtIdEspecialidad.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtIdEspecialidad_KeyPress);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(35, 197);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(166, 30);
            this.label2.TabIndex = 47;
            this.label2.Text = "Especialidad";
            // 
            // txtIdEmpleado
            // 
            this.txtIdEmpleado.Location = new System.Drawing.Point(274, 122);
            this.txtIdEmpleado.Name = "txtIdEmpleado";
            this.txtIdEmpleado.Size = new System.Drawing.Size(257, 37);
            this.txtIdEmpleado.TabIndex = 46;
            this.txtIdEmpleado.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtIdEmpleado_KeyPress);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(35, 125);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(167, 30);
            this.label1.TabIndex = 45;
            this.label1.Text = "ID Empleado";
            // 
            // btnLimpiar
            // 
            this.btnLimpiar.Location = new System.Drawing.Point(608, 609);
            this.btnLimpiar.Name = "btnLimpiar";
            this.btnLimpiar.Size = new System.Drawing.Size(169, 49);
            this.btnLimpiar.TabIndex = 44;
            this.btnLimpiar.Text = "Limpiar";
            this.btnLimpiar.UseVisualStyleBackColor = true;
            this.btnLimpiar.Click += new System.EventHandler(this.btnLimpiar_Click);
            // 
            // btnSalir
            // 
            this.btnSalir.Location = new System.Drawing.Point(423, 609);
            this.btnSalir.Name = "btnSalir";
            this.btnSalir.Size = new System.Drawing.Size(166, 49);
            this.btnSalir.TabIndex = 43;
            this.btnSalir.Text = "Salir";
            this.btnSalir.UseVisualStyleBackColor = true;
            this.btnSalir.Click += new System.EventHandler(this.btnSalir_Click);
            // 
            // btnEliminar
            // 
            this.btnEliminar.Location = new System.Drawing.Point(237, 609);
            this.btnEliminar.Name = "btnEliminar";
            this.btnEliminar.Size = new System.Drawing.Size(166, 49);
            this.btnEliminar.TabIndex = 42;
            this.btnEliminar.Text = "Eliminar";
            this.btnEliminar.UseVisualStyleBackColor = true;
            // 
            // grdVistaMedicos
            // 
            this.grdVistaMedicos.AllowUserToAddRows = false;
            this.grdVistaMedicos.AllowUserToDeleteRows = false;
            this.grdVistaMedicos.AllowUserToResizeColumns = false;
            this.grdVistaMedicos.AllowUserToResizeRows = false;
            this.grdVistaMedicos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grdVistaMedicos.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ID_SECRETARIO,
            this.idEmpleado,
            this.especialidad,
            this.numCertificacion});
            this.grdVistaMedicos.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.grdVistaMedicos.Location = new System.Drawing.Point(35, 331);
            this.grdVistaMedicos.Name = "grdVistaMedicos";
            this.grdVistaMedicos.RowHeadersWidth = 62;
            this.grdVistaMedicos.RowTemplate.Height = 33;
            this.grdVistaMedicos.Size = new System.Drawing.Size(757, 247);
            this.grdVistaMedicos.TabIndex = 41;
            // 
            // ID_SECRETARIO
            // 
            this.ID_SECRETARIO.DataPropertyName = "ID_MEDICO";
            this.ID_SECRETARIO.HeaderText = "ID";
            this.ID_SECRETARIO.MinimumWidth = 8;
            this.ID_SECRETARIO.Name = "ID_SECRETARIO";
            this.ID_SECRETARIO.ReadOnly = true;
            this.ID_SECRETARIO.Width = 150;
            // 
            // idEmpleado
            // 
            this.idEmpleado.DataPropertyName = "ID_EMPLEADO";
            this.idEmpleado.HeaderText = "ID Empleado";
            this.idEmpleado.MinimumWidth = 8;
            this.idEmpleado.Name = "idEmpleado";
            this.idEmpleado.Width = 180;
            // 
            // especialidad
            // 
            this.especialidad.DataPropertyName = "ESPECIALIDAD";
            this.especialidad.HeaderText = "Especialidad";
            this.especialidad.MinimumWidth = 8;
            this.especialidad.Name = "especialidad";
            this.especialidad.Width = 180;
            // 
            // numCertificacion
            // 
            this.numCertificacion.DataPropertyName = "NUM_CERTIFICACION";
            this.numCertificacion.HeaderText = "Num Certificación";
            this.numCertificacion.MinimumWidth = 8;
            this.numCertificacion.Name = "numCertificacion";
            this.numCertificacion.Width = 182;
            // 
            // btnGuardarMedico
            // 
            this.btnGuardarMedico.Location = new System.Drawing.Point(50, 609);
            this.btnGuardarMedico.Name = "btnGuardarMedico";
            this.btnGuardarMedico.Size = new System.Drawing.Size(166, 49);
            this.btnGuardarMedico.TabIndex = 40;
            this.btnGuardarMedico.Text = "Guardar";
            this.btnGuardarMedico.UseVisualStyleBackColor = true;
            this.btnGuardarMedico.Click += new System.EventHandler(this.btnGuardarMedico_Click);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(35, 64);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(137, 30);
            this.label13.TabIndex = 38;
            this.label13.Text = "ID Médico";
            // 
            // txtIdMedico
            // 
            this.txtIdMedico.Enabled = false;
            this.txtIdMedico.Location = new System.Drawing.Point(274, 57);
            this.txtIdMedico.Name = "txtIdMedico";
            this.txtIdMedico.Size = new System.Drawing.Size(257, 37);
            this.txtIdMedico.TabIndex = 39;
            // 
            // frmMedicos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(881, 732);
            this.Controls.Add(this.groupBox2);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmMedicos";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Médicos";
            this.Load += new System.EventHandler(this.frmMedicos_Load);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdVistaMedicos)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txtIdEmpleado;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnLimpiar;
        private System.Windows.Forms.Button btnSalir;
        private System.Windows.Forms.Button btnEliminar;
        private System.Windows.Forms.DataGridView grdVistaMedicos;
        private System.Windows.Forms.Button btnGuardarMedico;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtIdMedico;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtNumCerticado;
        private System.Windows.Forms.TextBox txtIdEspecialidad;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID_SECRETARIO;
        private System.Windows.Forms.DataGridViewTextBoxColumn idEmpleado;
        private System.Windows.Forms.DataGridViewTextBoxColumn especialidad;
        private System.Windows.Forms.DataGridViewTextBoxColumn numCertificacion;
    }
}