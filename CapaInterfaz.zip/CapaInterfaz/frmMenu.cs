﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace CapaInterfaz
{
    public partial class frmMenu : Form
    {
        public frmMenu()
        {
            InitializeComponent();
        }

        //Muestra formulario Pacientes
        private void pacientesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmPacientes frm = new frmPacientes();
            frm.Show();
        }  

        //Muestra formulario Expedientes
        private void expedientesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmExpedientes frm = new frmExpedientes();
            frm.Show();
        }

        //Muestra formulario Padecimientos
        private void padecimientosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmPadecimientos frm = new frmPadecimientos();
            frm.Show();
        }

        //Muestra formulario Tratamientos
        private void consultasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmTratamientos frm = new frmTratamientos();
            frm.Show();
        }

        //Muestra formulario Historial
        private void historialCitasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmHistorialCitas frm = new frmHistorialCitas();
            frm.Show();
        }

        //Muestra formulario Pagos
        private void pagosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmPagos frm = new frmPagos();
            frm.Show();
        }

        //Muestra formulario Usuarios
        private void usuariosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmUsuariosIngreso frm = new frmUsuariosIngreso();
            frm.Show();
        }

        //Muestra formulario Empledos
        private void empleadosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmEmpleados frm = new frmEmpleados();
            frm.Show();
        }

        //Muestra formulario Secretarios
        private void secretariosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmSecretarios frm = new frmSecretarios();
            frm.Show();
        }

        //Muestra formulario Medicos
        private void médicosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmMedicos frm = new frmMedicos();
            frm.Show();
        }

        //Muestra formulario Auxiliares
        private void auxiliaresToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmAuxiliares frm = new frmAuxiliares();
            frm.Show();
        }

        //Muestra formulario Agendas
        private void agendasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmAgendas frm = new frmAgendas();
            frm.Show();
        }

        //Muestra formulario Planillas
        private void planillasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmPlanillas frm = new frmPlanillas();
            frm.Show();
        }

        //Muestra formulario Consultas
        private void consultasToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            frmConsultas frm = new frmConsultas();
            frm.Show();
        }
    }//Fin clase frmMenu : Form
}//Fin namespace
