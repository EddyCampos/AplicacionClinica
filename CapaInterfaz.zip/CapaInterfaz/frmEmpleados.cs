﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using CapaEntidades;
using CapaLogica;

namespace CapaInterfaz
{
    public partial class frmEmpleados : Form
    {
        //Variable global del tipo del cliente que voy a abrir
        frmBuscarEmpleado formularioBuscar;

        //Variable global para un cliente
        EntidadEmpleados empleadoRegistrado;

        public frmEmpleados()
        {
            InitializeComponent();
        }

        //Cierra el formulario
        private void btnSalir_Click(object sender, EventArgs e)
        {
            Close();
        }//Fin btnSalir_Click

        //Genera entidad Empleado
        private EntidadEmpleados GenerarEntidadEmpleado()
        {
            EntidadEmpleados empleado = new EntidadEmpleados();

            empleado.SetNumCedula(txtCedula.Text);
            empleado.SetNumCarnet(txtCarnet.Text);
            empleado.SetNombre(txtNombre.Text);
            empleado.SetApellido01(txtApellido1.Text);
            empleado.SetApellido02(txtApellido2.Text);
            empleado.SetPais(txtPais.Text);
            empleado.SetProvincia(cboProvincia.Text);
            empleado.SetSexo(cboSexo.Text);
            empleado.SetFechaNacimiento(Convert.ToDateTime(dtpFnacimiento.Value));
            empleado.SetEstadoCivil(cboEstadoCivil.Text);
            empleado.SetCorreoElectronico(txtCorreo.Text);
            empleado.SetNumTelefono(txtTelefono.Text);
            empleado.SetEstado(cboEstado.Text);
            return empleado;
        }//Fin GenerarEntidadEmpleado

        //Cancela el evento cuando se ingresan letras o simbolos, valida solo numeros
        public void ValidarSoloNum(object sender, KeyPressEventArgs e)
        {
            if (char.IsDigit(e.KeyChar) || e.KeyChar == 8)//TECLAS: NUMEROS Y BORRAR
            {
                //NO SE CANCELA EL EVENTO
                e.Handled = false;
            }
            else
            {
                //CANCELA EL EVENTO
                e.Handled = true;
            }
        }//Fin ValidarSoloNum

        //Cancela el evento cuando se ingresan numeros o simbolos, valida solo letras
        private void ValidarSoloTxt(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar) || e.KeyChar == 8 || e.KeyChar == 32)//TECLAS: LETRAS Y BORRAR
            {
                //NO SE CANCELA EL EVENTO
                e.Handled = false;
            }
            else
            {
                //CANCELA EL EVENTO
                e.Handled = true;
            }
        }//Fin ValidarSoloTxt

        //Guarda en la BD
        private void btnGuardarEmpleado_Click(object sender, EventArgs e)
        {
            BLEmpleados logica = new BLEmpleados(Configuracion.getConnectionString);

            EntidadEmpleados empleado;

            int resultado;
            string mensaje = string.Empty;

            try
            {
                if (!string.IsNullOrEmpty(txtCedula.Text)&&
                    !string.IsNullOrEmpty(txtCarnet.Text)&&
                    !string.IsNullOrEmpty(txtNombre.Text)&&
                    !string.IsNullOrEmpty(txtApellido1.Text)&&
                    !string.IsNullOrEmpty(txtApellido2.Text)&&
                    !string.IsNullOrEmpty(txtPais.Text)&&
                    !string.IsNullOrEmpty(cboProvincia.Text)&&
                    !string.IsNullOrEmpty(cboSexo.Text)&&
                    !string.IsNullOrEmpty(dtpFnacimiento.Text)&&
                    !string.IsNullOrEmpty(cboEstadoCivil.Text)&&
                    !string.IsNullOrEmpty(txtCorreo.Text) &&
                    !string.IsNullOrEmpty(txtTelefono.Text) &&
                    !string.IsNullOrEmpty(cboEstado.Text))
                {
                    empleado = GenerarEntidadEmpleado();
                    resultado = logica.InsertarEmpleado(empleado);
                    MessageBox.Show("Empleado insertado Correctamente", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    limpiar();
                    CargarListaEmpleados();
                }
                else
                {
                    MessageBox.Show("Datos obligatorios", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }//Fin btnGuardarEmpleado_Click

        //Cargar la lista de clientes con un DATASET
        public void CargarListaEmpleados(string condicion = "", string orden = "")
        {
            BLEmpleados logica = new BLEmpleados(Configuracion.getConnectionString);
            DataSet DSEmpleados;

            try
            {
                DSEmpleados = logica.ListarEmpleados(condicion, orden);
                grdVistaEmpleados.DataSource = DSEmpleados;
                grdVistaEmpleados.DataMember = DSEmpleados.Tables["Empleados"].TableName;
            }
            catch (Exception)
            {

                MessageBox.Show("Ocurrió un error", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }//Fin CargarListaEmpleados

        //Limpia todas las casillas
        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            limpiar();
        }//Fin btnLimpiar_Click

        //Cuando carga el formulario que cargue la vista de la tabla
        private void frmEmpleados_Load(object sender, EventArgs e)
        {
            try
            {
                CargarListaEmpleados();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }//Fin frmEmpleados_Load

        //Solo permite llenar el campo con numeros
        private void txtCedula_KeyPress(object sender, KeyPressEventArgs e)
        {
            ValidarSoloNum(sender, e);
        }

        //Solo permite llenar el campo con letras
        private void txtNombre_KeyPress(object sender, KeyPressEventArgs e)
        {
            ValidarSoloTxt(sender, e);
        }

        //Solo permite llenar el campo con letras
        private void txtApellido1_KeyPress(object sender, KeyPressEventArgs e)
        {
            ValidarSoloTxt(sender, e);
        }

        //Solo permite llenar el campo con letras
        private void txtApellido2_KeyPress(object sender, KeyPressEventArgs e)
        {
            ValidarSoloTxt(sender, e);
        }

        //Solo permite llenar el campo con letras
        private void txtPais_KeyPress(object sender, KeyPressEventArgs e)
        {
            ValidarSoloTxt(sender, e);
        }

        //Solo permite llenar el campo con numeros
        private void txtTelefono_KeyPress(object sender, KeyPressEventArgs e)
        {
            ValidarSoloNum(sender, e);
        }

        //Limpia info de los espacios
        private void limpiar()
        {
            txtIdEmpleado.Text = string.Empty;
            txtCedula.Text = string.Empty;
            txtCarnet.Text = string.Empty;
            txtNombre.Text = string.Empty;
            txtApellido1.Text = string.Empty;
            txtApellido2.Text = string.Empty;
            txtPais.Text = string.Empty;
            cboProvincia.SelectedIndex = 0;
            cboSexo.SelectedIndex = 0;
            dtpFnacimiento.Value = Convert.ToDateTime("01/01/1900");
            cboEstadoCivil.SelectedIndex = 0;
            txtCorreo.Text = string.Empty;
            txtTelefono.Text = string.Empty;
            cboEstado.SelectedIndex = 0;

        }//Fin limpiar

        //Método cargar los datos del cliente recuperados por medio de la cedula del form Buscar
        private void CargarEmpleadoEncontrado(int id)
        {
            EntidadEmpleados empleado = new EntidadEmpleados();
            BLEmpleados traerEmpleado = new BLEmpleados(Configuracion.getConnectionString);

            try
            {
                empleado = traerEmpleado.ObtenerEmpleado(id);
                if (empleado != null)
                {
                    txtIdEmpleado.Text = empleado.GetIdEmpleado().ToString();
                    txtCedula.Text = empleado.GetNumCedula();
                    txtCarnet.Text = empleado.GetNumCarnet();
                    txtNombre.Text = empleado.GetNombre();
                    txtApellido1.Text = empleado.GetApellido01();
                    txtApellido2.Text = empleado.GetApellido02();
                    txtPais.Text = empleado.GetPais();
                    cboProvincia.Text = empleado.GetProvincia();
                    cboSexo.Text = empleado.GetSexo();
                    dtpFnacimiento.Text = empleado.GetFNacimiento().ToString();
                    cboEstadoCivil.Text = empleado.GetEstadoCivil();
                    txtCorreo.Text = empleado.GetCorreoElectronico();
                    txtTelefono.Text = empleado.GetNumTelefono();
                    cboEstado.Text = empleado.GetEstado();
                    empleadoRegistrado = empleado;

                    
                }
                else
                {
                    MessageBox.Show("Cliente no está en la BD", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    CargarListaEmpleados();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }//Fin CargarEmpleadoEncontrado

        //Evento cuando se da click al boton de aceptar en el formulario de Buscar Paciente
        private void Aceptar(object id, EventArgs e)
        {
            try
            {
                int idEmpleado = (int)id;
                if (idEmpleado != -1)
                {
                    //MessageBox.Show(idCliente.ToString());
                    CargarEmpleadoEncontrado(idEmpleado);
                }
                else
                {
                    //Limpiar();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }//Fin Aceptar

        //Boton elimina empleado con procedimietno almacenado de la BD
        private void btnEliminar_Click(object sender, EventArgs e)
        {
            EntidadEmpleados empleado;
            int resultado;

            BLEmpleados logica = new BLEmpleados(Configuracion.getConnectionString);

            try
            {
                if (!string.IsNullOrEmpty(txtIdEmpleado.Text))
                {
                    empleado = logica.ObtenerEmpleado(int.Parse(txtIdEmpleado.Text));//Se obtiene la entidad

                    if (empleado != null)
                    {
                        //Eliminar con Procedimiento Almacenado
                        resultado = logica.EliminarEmpleadoConSP(empleado);
                        MessageBox.Show(logica.Mensaje, "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        limpiar();
                        CargarListaEmpleados();
                    }
                    else
                    {
                        MessageBox.Show("Cliente no existe", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        limpiar();
                        CargarListaEmpleados();
                    }
                }
                else
                {
                    MessageBox.Show("Debe seleccionar un cliente", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }//Fin btnEliminar_Click

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            formularioBuscar = new frmBuscarEmpleado();

            //Especificar que se va a usar el evento aceptar, eventhandler captura un evento
            formularioBuscar.Aceptar += new EventHandler(Aceptar);

            //Que se esta abriendo de otro formulario
            formularioBuscar.ShowDialog();
        }
    }//Fin clase frmEmpleados : Form
}//Fin namespace
