﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using CapaLogica;
using CapaEntidades;
using static System.Windows.Forms.MonthCalendar;

namespace CapaInterfaz
{
    public partial class frmExpedientes : Form
    {
        public frmExpedientes()
        {
            InitializeComponent();
        }

        //Recibe el id del paciente
        private string idPacienteSeleccionado;
        public frmExpedientes(string idPacienteSeleccionado)
        {
            InitializeComponent();
            this.idPacienteSeleccionado = idPacienteSeleccionado;
        }

        //Cierra el formulario
        private void btnSalir_Click(object sender, EventArgs e)
        {
            Close();
        }//Fin btnSalir_Click

        //Genera entidad
        private EntidadExpedientes GenerarEntidadExpedientes()
        {
            EntidadExpedientes expediente = new EntidadExpedientes();

            expediente.SetIdPaciente(Convert.ToInt32(txtIdPaciente.Text));
            expediente.SetFCreacion(Convert.ToDateTime(dtpFCreacion.Value));

            return expediente;
        }//Fin GenerarEntidadExpedientes

        //Guarda en la base de datos
        private void btnGuardarExpediente_Click(object sender, EventArgs e)
        {
            BLExpedientes logica = new BLExpedientes(Configuracion.getConnectionString);

            EntidadExpedientes expediente;
            int resultado;

            try
            {
                if (!string.IsNullOrEmpty(txtIdPaciente.Text) &&
                    !string.IsNullOrEmpty(dtpFCreacion.Text))
                {
                    expediente = GenerarEntidadExpedientes();
                    resultado = logica.InsertarExpediente(expediente);
                    MessageBox.Show("Expediente insertado Correctamente", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    limpiar();
                    CargarExpedientes();
                }
                else
                {
                    MessageBox.Show("Datos obligatorios", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }//Fin btnGuardarExpediente_Click

        //Cargar toda la lista con un DATASET
        public void CargarExpedientes(string condicion = "", string orden = "")
        {
            BLExpedientes logica = new BLExpedientes(Configuracion.getConnectionString);
            DataSet DSExpedientes;

            try
            {
                DSExpedientes = logica.ListarExpedientes(condicion, orden, idPacienteSeleccionado);
                grdVistaExpedientes.DataSource = DSExpedientes;
                grdVistaExpedientes.DataMember = DSExpedientes.Tables["EXPEDIENTES"].TableName;
            }
            catch (Exception)
            {
                MessageBox.Show("Ocurrió un error", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }//Fin CargarListaMedicos

        //Cuando carga el formulario que cargue la vista de la tabla
        private void frmExpedientes_Load(object sender, EventArgs e)
        {
            try
            {
                CargarExpedientes(idPacienteSeleccionado);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }//Fin frmExpedientes_Load


        //Limpia info de los espacios
        private void limpiar()
        {
            txtIdExpediente.Text = string.Empty;
            txtIdPaciente.Text = string.Empty;
            dtpFCreacion.Value = Convert.ToDateTime("01/01/1900");
        }//Fin limpiar

        //Boton limpia todas las casillas
        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            limpiar();
        }//Fin btnLimpiar_Click

        //Cancela el evento cuando se ingresan letras o simbolos, valida solo numeros
        public void ValidarSoloNum(object sender, KeyPressEventArgs e)
        {
            if (char.IsDigit(e.KeyChar) || e.KeyChar == 8)//TECLAS: NUMEROS Y BORRAR
            {
                //NO SE CANCELA EL EVENTO
                e.Handled = false;
            }
            else
            {
                //CANCELA EL EVENTO
                e.Handled = true;
            }
        }//Fin ValidarSoloNum

        //Solo permite llenar el campo con numeros
        private void txtIdPaciente_KeyPress(object sender, KeyPressEventArgs e)
        {
            ValidarSoloNum(sender, e);
        }
    }//Fin clase frmExpedientes : Form
}//Fin namespace
