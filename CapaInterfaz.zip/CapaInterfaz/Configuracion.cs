﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CapaInterfaz
{
    class Configuracion
    {
        //Método para obtener la cadena de conexion a la BD
        public static string getConnectionString
        {
            get
            {
                return Properties.Settings.Default.ConnectionString;
            }
        }
    }//Fin class Configuracion
}//Fin namesapce
