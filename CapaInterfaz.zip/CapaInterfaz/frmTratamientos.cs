﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using CapaEntidades;
using CapaLogica;

namespace CapaInterfaz
{
    public partial class frmTratamientos : Form
    {
        public frmTratamientos()
        {
            InitializeComponent();
        }

        //Cierra el formulario
        private void btnSalir_Click(object sender, EventArgs e)
        {
            Close();
        }//Fin btnSalir_Click

        //Genera Entidad
        private EntidadTratamientos GenerarEntidadTratamientos()
        {
            EntidadTratamientos tratamiento = new EntidadTratamientos();

            tratamiento.SetIdPadecimiento(Convert.ToInt32(txtIdPadecimiento.Text));
            tratamiento.SetNombre(txtNombre.Text);
            tratamiento.SetDosis(txtDosis.Text);
            tratamiento.SetDuracion(txtDuracion.Text);
            tratamiento.SetEstado(cboEstado.Text);

            return tratamiento;
        }//Fin GenerarEntidadTratamientos

        //Guarda en la base de datos
        private void btnGuardarTratamiento_Click(object sender, EventArgs e)
        {
            BLTratamientos logica = new BLTratamientos(Configuracion.getConnectionString);

            EntidadTratamientos tratamiento;
            int resultado;

            try
            {
                if (!string.IsNullOrEmpty(txtIdPadecimiento.Text) &&
                    !string.IsNullOrEmpty(txtNombre.Text) &&
                    !string.IsNullOrEmpty(txtDuracion.Text) &&
                    !string.IsNullOrEmpty(txtDosis.Text) &&
                    !string.IsNullOrEmpty(cboEstado.Text))
                {
                    tratamiento = GenerarEntidadTratamientos();
                    resultado = logica.InsertarTratamiento(tratamiento);
                    MessageBox.Show("Tratamiento insertado Correctamente", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    limpiar();
                    CargarListaTratamientos();
                }
                else
                {
                    MessageBox.Show("Datos obligatorios", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }//Fin btnGuardarTratamiento_Click

        //Cargar la lista de clientes con un DATASET
        public void CargarListaTratamientos(string condicion = "", string orden = "")
        {
            BLTratamientos logica = new BLTratamientos(Configuracion.getConnectionString);
            DataSet DSTratamientos;

            try
            {
                DSTratamientos = logica.ListarTratamientos(condicion, orden);
                grdVistaTratamientos.DataSource = DSTratamientos;
                grdVistaTratamientos.DataMember = DSTratamientos.Tables["TRATAMIENTOS"].TableName;
            }
            catch (Exception)
            {

                MessageBox.Show("Ocurrió un error", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }//Fin CargarListaTratamientos

        //Cuando carga el formulario que cargue la vista de la tabla 
        private void frmTratamientos_Load(object sender, EventArgs e)
        {
            try
            {
                CargarListaTratamientos();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }//Fin frmTratamientos_Load

        //Limpia info de los espacios
        private void limpiar()
        {
            txtIdTratamiento.Text = string.Empty;
            txtIdPadecimiento.Text = string.Empty;
            txtNombre.Text = string.Empty;
            txtDosis.Text = string.Empty;
            txtDuracion.Text = string.Empty;
            cboEstado.SelectedIndex = 0;
        }//Fin limpiar

        //Boton limpia todas las casillas
        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            limpiar();
        }//Fin btnLimpiar_Click

        //Cancela el evento cuando se ingresan letras o simbolos, valida solo numeros
        public void ValidarSoloNum(object sender, KeyPressEventArgs e)
        {
            if (char.IsDigit(e.KeyChar) || e.KeyChar == 8)//TECLAS: NUMEROS Y BORRAR
            {
                //NO SE CANCELA EL EVENTO
                e.Handled = false;
            }
            else
            {
                //CANCELA EL EVENTO
                e.Handled = true;
            }
        }//Fin ValidarSoloNum

        //Solo permite llenar el campo con numeros
        private void txtIdPadecimiento_KeyPress(object sender, KeyPressEventArgs e)
        {
            ValidarSoloNum(sender, e);
        }

    }//Fin clase frmTratamientos : Form
}//Fin namespace
