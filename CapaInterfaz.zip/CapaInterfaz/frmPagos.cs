﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using CapaEntidades;
using CapaLogica;

namespace CapaInterfaz
{
    public partial class frmPagos : Form
    {
        public frmPagos()
        {
            InitializeComponent();
        }

        //Cierra el formulario
        private void btnSalir_Click(object sender, EventArgs e)
        {
            Close();
        }//Fin btnSalir_Click

        //Genera Entidad
        private EntidadPagos GenerarEntidadPagos()
        {
            EntidadPagos pago = new EntidadPagos();

            pago.SetIdPaciente(Convert.ToInt32(txtIdPaciente));
            pago.SetMonto(Convert.ToInt32(txtMonto));
            pago.SetMetodoPago(txtMetPago.Text);
            pago.SetEstado(cboEstado.Text);

            return pago;
        }//Fin GenerarEntidadPagos

        //Guarda en la base de datos
        private void btnGuardarPago_Click(object sender, EventArgs e)
        {
            BLPagos logica = new BLPagos(Configuracion.getConnectionString);

            EntidadPagos pago;
            int resultado;

            try
            {
                if (!string.IsNullOrEmpty(txtIdPaciente.Text) &&
                    !string.IsNullOrEmpty(txtMonto.Text) &&
                    !string.IsNullOrEmpty(txtMetPago.Text) &&
                    !string.IsNullOrEmpty(cboEstado.Text))
                {
                    pago = GenerarEntidadPagos();
                    resultado = logica.InsertarPago(pago);
                    MessageBox.Show("Pago insertado Correctamente", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    limpiar();
                    CargarListaPagos();
                }
                else
                {
                    MessageBox.Show("Datos obligatorios", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }//Fin btnGuardarPago_Click

        //Cargar la lista de clientes con un DATASET
        public void CargarListaPagos(string condicion = "", string orden = "")
        {
            BLPagos logica = new BLPagos(Configuracion.getConnectionString);
            DataSet DSPagos;

            try
            {
                DSPagos = logica.ListarPagos(condicion, orden);
                grdVistaPagos.DataSource = DSPagos;
                grdVistaPagos.DataMember = DSPagos.Tables["PAGOS"].TableName;
            }
            catch (Exception)
            {

                MessageBox.Show("Ocurrió un error", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }//Fin CargarListaPagos

        //Cierra el formulario
        private void btnSalir_Click_1(object sender, EventArgs e)
        {
            Close();
        }//Fin btnSalir_Click_1

        //Limpia info de los espacios
        private void limpiar() { 
            txtIdPago.Text = string.Empty;
            txtIdPaciente.Text = string.Empty;
            txtMetPago.Text = string.Empty;
            txtMonto.Text = string.Empty;
            cboEstado.SelectedIndex = 0;

        }//Fin limpiar

        //Boton limpia todas las casillas
        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            limpiar();
        }//Fin btnLimpiar_Click

        //Cancela el evento cuando se ingresan letras o simbolos, valida solo numeros
        public void ValidarSoloNum(object sender, KeyPressEventArgs e)
        {
            if (char.IsDigit(e.KeyChar) || e.KeyChar == 8)//TECLAS: NUMEROS Y BORRAR
            {
                //NO SE CANCELA EL EVENTO
                e.Handled = false;
            }
            else
            {
                //CANCELA EL EVENTO
                e.Handled = true;
            }
        }//Fin ValidarSoloNum

        //Cancela el evento cuando se ingresan numeros o simbolos, valida solo letras
        private void ValidarSoloTxt(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar) || e.KeyChar == 8 || e.KeyChar == 32)//TECLAS: LETRAS Y BORRAR
            {
                //NO SE CANCELA EL EVENTO
                e.Handled = false;
            }
            else
            {
                //CANCELA EL EVENTO
                e.Handled = true;
            }
        }//Fin ValidarSoloTxt

        //Solo permite llenar el campo con numeros
        private void txtIdPaciente_KeyPress(object sender, KeyPressEventArgs e)
        {
            ValidarSoloNum(sender, e);
        }

        //Solo permite llenar el campo con numeros
        private void txtMonto_KeyPress(object sender, KeyPressEventArgs e)
        {
            ValidarSoloNum(sender, e);
        }

        //Solo permite llenar el campo con letras
        private void txtMetPago_KeyPress(object sender, KeyPressEventArgs e)
        {
            ValidarSoloTxt(sender, e);
        }
    }//Fin clase frmPagos : Form
}//Fin namespace
