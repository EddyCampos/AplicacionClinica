﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using CapaEntidades;
using CapaLogica;

namespace CapaInterfaz
{
    public partial class frmConsultas : Form
    {
        //Variable toman el valor del dia hora y fecha de la consulta para verificar choques
        int idMedicoCheck = 0;
        DateTime? horaCheck = Convert.ToDateTime("01/01/1900");
        DateTime? diaCheck = Convert.ToDateTime("01/01/1900");

        public frmConsultas()
        {
            InitializeComponent();
        }

        //Cierra el formulario
        private void btnSalir_Click(object sender, EventArgs e)
        {
            Close();
        }//Fin btnSalir_Click

        //Generar Entidad
        private EntidadConsultas GenerarEntidadConsultas()
        {
            EntidadConsultas consulta = new EntidadConsultas();
            
            consulta.SetIdMedico(Convert.ToInt32(txtIdMedico.Text));
            consulta.SetIdPaciente(Convert.ToInt32(txtIdPaciente.Text));
            consulta.SetDia(Convert.ToDateTime(dtpFecha.Value));
            consulta.SetHora(Convert.ToDateTime(txtHora.Text));
            consulta.SetMotivo(txtMotivo.Text);

            return consulta;
        }//Fin GenerarEntidadConsultas

        //Revisa choque de horarios
        private bool ValidarChoqueHorarios()
        {
            EntidadConsultas consulta = new EntidadConsultas();

            DateTime horaSalida = horaCheck.Value.AddMinutes(30);

            bool choque = false;

            CargarHorario(consulta.GetIdMedico());

            if(consulta.GetHora() < horaCheck ||
                consulta.GetHora() < horaSalida || 
                consulta.GetDia() == diaCheck ||
                consulta.GetDia() < DateTime.Now.AddDays(2)
                )
            {
                choque = true;
            }

            return choque;
        }//Fin ValidarChoqueHorarios

        //Método cargar los datos del horario recuperados
        private void CargarHorario(int id)
        {
            EntidadConsultas horario = new EntidadConsultas();
            BLConsultas traerHorario = new BLConsultas(Configuracion.getConnectionString);

            try
            {
                //horario = traerHorario.ObtenerListaConsultas(id);
                if (horario != null)
                {
                    idMedicoCheck = horario.GetIdMedico();
                    horaCheck = horario.GetHora();
                    diaCheck = horario.GetDia();                    
                }
                
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }//Fin CargarCliente


        //Guarda en la base de datos
        private void btnGuardarConsulta_Click(object sender, EventArgs e)
        {
            BLConsultas logica = new BLConsultas(Configuracion.getConnectionString);

            EntidadConsultas consulta;
            int resultado;

            try
            {
                if (!string.IsNullOrEmpty(txtIdMedico.Text) &&
                    !string.IsNullOrEmpty(txtIdPaciente.Text) &&
                    !string.IsNullOrEmpty(dtpFecha.Text) &&
                    !string.IsNullOrEmpty(txtHora.Text) &&
                    !string.IsNullOrEmpty(txtMotivo.Text))
                {
                    
                    if (!ValidarChoqueHorarios())
                    {
                        consulta = GenerarEntidadConsultas();
                        resultado = logica.InsertarConsulta(consulta);
                        MessageBox.Show("Consulta insertada Correctamente", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        limpiar();
                        CargarListaConsultas();
                    }
                    else
                    {
                        MessageBox.Show("Existe un choque de horarios", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }                   
                }
                else
                {
                    MessageBox.Show("Datos obligatorios", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }//Fin btnGuardarConsulta_Click

        //Cargar la lista de clientes con un DATASET
        public void CargarListaConsultas(string condicion = "", string orden = "")
        {
            BLConsultas logica = new BLConsultas(Configuracion.getConnectionString);
            DataSet DSConsultas;

            try
            {
                DSConsultas = logica.ListarConsultas(condicion, orden);
                grdVistaConsultas.DataSource = DSConsultas;
                grdVistaConsultas.DataMember = DSConsultas.Tables["CONSULTAS"].TableName;
            }
            catch (Exception)
            {

                MessageBox.Show("Ocurrió un error", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }//Fin CargarListaAgenda

        //Cuando carga el formulario que cargue la vista de la tabla
        private void frmConsultas_Load(object sender, EventArgs e)
        {
            try
            {
                CargarListaConsultas();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }//Fin frmConsultas_Load

        //Limpia info de los espacios
        private void limpiar()
        {
            txtIdConsulta.Text = string.Empty;
            txtIdMedico.Text = string.Empty;
            txtIdPaciente.Text = string.Empty;
            dtpFecha.Value.AddDays(1);
            txtHora.Text = string.Empty;
            txtMotivo.Text = string.Empty;
        }//Fin Limpiar

        //Boton limpia la info
        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            limpiar();
        }//Fin btnLimpiar_Click

        //Cancela el evento cuando se ingresan letras o simbolos, valida solo numeros
        public void ValidarSoloNum(object sender, KeyPressEventArgs e)
        {
            if (char.IsDigit(e.KeyChar) || e.KeyChar == 8)//TECLAS: NUMEROS Y BORRAR
            {
                //NO SE CANCELA EL EVENTO
                e.Handled = false;
            }
            else
            {
                //CANCELA EL EVENTO
                e.Handled = true;
            }
        }//Fin ValidarSoloNum

        //Cancela el evento cuando se ingresan numeros o simbolos, valida solo letras
        private void ValidarSoloTxt(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar) || e.KeyChar == 8 || e.KeyChar == 32)//TECLAS: LETRAS Y BORRAR
            {
                //NO SE CANCELA EL EVENTO
                e.Handled = false;
            }
            else
            {
                //CANCELA EL EVENTO
                e.Handled = true;
            }
        }//Fin ValidarSoloTxt

        //Solo permite llenar el campo con numeros
        private void txtIdMedico_KeyPress(object sender, KeyPressEventArgs e)
        {
            ValidarSoloNum(sender, e);
        }

        //Solo permite llenar el campo con numeros
        private void txtIdPaciente_KeyPress(object sender, KeyPressEventArgs e)
        {
            ValidarSoloNum(sender, e);
        }

        //Solo permite llenar el campo con letras
        private void txtMotivo_KeyPress(object sender, KeyPressEventArgs e)
        {
            ValidarSoloTxt(sender, e);
        }
    }//Fin clase frmConsultas : Form
}//Fin namespace
