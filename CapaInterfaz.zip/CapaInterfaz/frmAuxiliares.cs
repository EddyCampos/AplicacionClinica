﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using CapaLogica;
using CapaEntidades;

namespace CapaInterfaz
{
    public partial class frmAuxiliares : Form
    {
        public frmAuxiliares()
        {
            InitializeComponent();
        }

        //Cierra el formulario
        private void btnSalir_Click(object sender, EventArgs e)
        {
            Close();
        }//Fin btnSalir_Click

        //Genera entidad
        public EntidadAuxiliares GenerarEntidadAuxiliares()
        {
            EntidadAuxiliares auxiliar = new EntidadAuxiliares();

            auxiliar.SetIdEmpleado(Convert.ToInt32(txtIdEmpleado.Text));
            auxiliar.SetArea(txtArea.Text);

            return auxiliar;
        }//Fin GenerarEntidadAuxiliares

        //Guarda en la base de datos
        private void btnGuardarAuxiliar_Click(object sender, EventArgs e)
        {
            BLAuxiliares logica = new BLAuxiliares(Configuracion.getConnectionString);

            EntidadAuxiliares auxiliar;
            int resultado;

            try
            {
                if (!string.IsNullOrEmpty(txtIdEmpleado.Text)&&
                    !string.IsNullOrEmpty(txtArea.Text))
                {
                    auxiliar = GenerarEntidadAuxiliares();
                    resultado = logica.InsertarAuxiliar(auxiliar);
                    MessageBox.Show("Auxiliar insertado Correctamente", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    Limpiar();
                    CargarListaAuxiliares();
                }
                else
                {
                    MessageBox.Show("Datos obligatorios", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }//Fin btnGuardarAuxiliar_Click

        //Cargar la lista de clientes con un DATASET
        public void CargarListaAuxiliares(string condicion = "", string orden = "")
        {
            BLAuxiliares logica = new BLAuxiliares(Configuracion.getConnectionString);
            DataSet DSAuxiliares;

            try
            {
                DSAuxiliares = logica.ListarAuxiliares(condicion, orden);
                grdVistaAuxiliares.DataSource = DSAuxiliares;
                grdVistaAuxiliares.DataMember = DSAuxiliares.Tables["AUXILIARES"].TableName;
            }
            catch (Exception)
            {

                MessageBox.Show("Ocurrió un error", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }//Fin CargarListaMedicos

        //Cuando carga el formulario que cargue la vista de la tabla
        private void frmAuxiliares_Load(object sender, EventArgs e)
        {
            try
            {
                CargarListaAuxiliares();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }//Fin frmAuxiliares_Load

        //Limpia info de los espacios
        private void Limpiar()
        {
            txtIdAuxiliar.Text = string.Empty;
            txtIdEmpleado.Text = string.Empty;
            txtArea.Text = string.Empty;
        }//Fin Limpiar

        //Boton limpia la info
        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            Limpiar();
        }//Fin btnLimpiar_Click

        //Cancela el evento cuando se ingresan letras o simbolos, valida solo numeros
        public void ValidarSoloNum(object sender, KeyPressEventArgs e)
        {
            if (char.IsDigit(e.KeyChar) || e.KeyChar == 8)//TECLAS: NUMEROS Y BORRAR
            {
                //NO SE CANCELA EL EVENTO
                e.Handled = false;
            }
            else
            {
                //CANCELA EL EVENTO
                e.Handled = true;
            }
        }//Fin ValidarSoloNum

        //Cancela el evento cuando se ingresan numeros o simbolos, valida solo letras
        private void ValidarSoloTxt(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar) || e.KeyChar == 8 || e.KeyChar == 32)//TECLAS: LETRAS Y BORRAR
            {
                //NO SE CANCELA EL EVENTO
                e.Handled = false;
            }
            else
            {
                //CANCELA EL EVENTO
                e.Handled = true;
            }
        }//Fin ValidarSoloTxt

        //Solo permite llenar el campo con numeros
                private void txtIdEmpleado_KeyPress(object sender, KeyPressEventArgs e)
        {
            ValidarSoloNum(sender, e);
        }

        //Solo permite llenar el campo con letras
        private void txtArea_KeyPress(object sender, KeyPressEventArgs e)
        {
            ValidarSoloTxt(sender, e);
        }
    }//Fin clase frmAuxiliares : Form
}//Fin namespace
