﻿namespace CapaInterfaz
{
    partial class frmTratamientos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.cboEstado = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtDuracion = new System.Windows.Forms.TextBox();
            this.txtDosis = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtNombre = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtIdPadecimiento = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnLimpiar = new System.Windows.Forms.Button();
            this.btnSalir = new System.Windows.Forms.Button();
            this.btnEliminar = new System.Windows.Forms.Button();
            this.grdVistaTratamientos = new System.Windows.Forms.DataGridView();
            this.idTratamiento = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idPadecimiento = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nombre = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dosis = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.duracion = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.estado = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnGuardarTratamiento = new System.Windows.Forms.Button();
            this.label13 = new System.Windows.Forms.Label();
            this.txtIdTratamiento = new System.Windows.Forms.TextBox();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdVistaTratamientos)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.cboEstado);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.txtDuracion);
            this.groupBox2.Controls.Add(this.txtDosis);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.txtNombre);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.txtIdPadecimiento);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.btnLimpiar);
            this.groupBox2.Controls.Add(this.btnSalir);
            this.groupBox2.Controls.Add(this.btnEliminar);
            this.groupBox2.Controls.Add(this.grdVistaTratamientos);
            this.groupBox2.Controls.Add(this.btnGuardarTratamiento);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.txtIdTratamiento);
            this.groupBox2.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.groupBox2.Location = new System.Drawing.Point(29, 28);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(885, 832);
            this.groupBox2.TabIndex = 42;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Tratamiento";
            // 
            // cboEstado
            // 
            this.cboEstado.FormattingEnabled = true;
            this.cboEstado.Items.AddRange(new object[] {
            "ACT",
            "INA"});
            this.cboEstado.Location = new System.Drawing.Point(274, 400);
            this.cboEstado.Name = "cboEstado";
            this.cboEstado.Size = new System.Drawing.Size(257, 38);
            this.cboEstado.TabIndex = 56;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(35, 408);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(92, 30);
            this.label5.TabIndex = 55;
            this.label5.Text = "Estado";
            // 
            // txtDuracion
            // 
            this.txtDuracion.Location = new System.Drawing.Point(274, 327);
            this.txtDuracion.Name = "txtDuracion";
            this.txtDuracion.Size = new System.Drawing.Size(257, 37);
            this.txtDuracion.TabIndex = 53;
            // 
            // txtDosis
            // 
            this.txtDosis.Location = new System.Drawing.Point(274, 259);
            this.txtDosis.Name = "txtDosis";
            this.txtDosis.Size = new System.Drawing.Size(257, 37);
            this.txtDosis.TabIndex = 52;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(35, 334);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(122, 30);
            this.label4.TabIndex = 51;
            this.label4.Text = "Duración";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(35, 266);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(73, 30);
            this.label3.TabIndex = 50;
            this.label3.Text = "Dosis";
            // 
            // txtNombre
            // 
            this.txtNombre.Location = new System.Drawing.Point(274, 190);
            this.txtNombre.Name = "txtNombre";
            this.txtNombre.Size = new System.Drawing.Size(257, 37);
            this.txtNombre.TabIndex = 49;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(35, 197);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(110, 30);
            this.label2.TabIndex = 47;
            this.label2.Text = "Nombre";
            // 
            // txtIdPadecimiento
            // 
            this.txtIdPadecimiento.Location = new System.Drawing.Point(274, 122);
            this.txtIdPadecimiento.Name = "txtIdPadecimiento";
            this.txtIdPadecimiento.Size = new System.Drawing.Size(257, 37);
            this.txtIdPadecimiento.TabIndex = 46;
            this.txtIdPadecimiento.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtIdPadecimiento_KeyPress);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(35, 125);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(213, 30);
            this.label1.TabIndex = 45;
            this.label1.Text = "ID Padecimiento";
            // 
            // btnLimpiar
            // 
            this.btnLimpiar.Location = new System.Drawing.Point(630, 747);
            this.btnLimpiar.Name = "btnLimpiar";
            this.btnLimpiar.Size = new System.Drawing.Size(169, 49);
            this.btnLimpiar.TabIndex = 44;
            this.btnLimpiar.Text = "Limpiar";
            this.btnLimpiar.UseVisualStyleBackColor = true;
            this.btnLimpiar.Click += new System.EventHandler(this.btnLimpiar_Click);
            // 
            // btnSalir
            // 
            this.btnSalir.Location = new System.Drawing.Point(445, 747);
            this.btnSalir.Name = "btnSalir";
            this.btnSalir.Size = new System.Drawing.Size(166, 49);
            this.btnSalir.TabIndex = 43;
            this.btnSalir.Text = "Salir";
            this.btnSalir.UseVisualStyleBackColor = true;
            this.btnSalir.Click += new System.EventHandler(this.btnSalir_Click);
            // 
            // btnEliminar
            // 
            this.btnEliminar.Location = new System.Drawing.Point(259, 747);
            this.btnEliminar.Name = "btnEliminar";
            this.btnEliminar.Size = new System.Drawing.Size(166, 49);
            this.btnEliminar.TabIndex = 42;
            this.btnEliminar.Text = "Eliminar";
            this.btnEliminar.UseVisualStyleBackColor = true;
            // 
            // grdVistaTratamientos
            // 
            this.grdVistaTratamientos.AllowUserToAddRows = false;
            this.grdVistaTratamientos.AllowUserToDeleteRows = false;
            this.grdVistaTratamientos.AllowUserToResizeColumns = false;
            this.grdVistaTratamientos.AllowUserToResizeRows = false;
            this.grdVistaTratamientos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grdVistaTratamientos.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idTratamiento,
            this.idPadecimiento,
            this.nombre,
            this.dosis,
            this.duracion,
            this.estado});
            this.grdVistaTratamientos.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.grdVistaTratamientos.Location = new System.Drawing.Point(35, 473);
            this.grdVistaTratamientos.Name = "grdVistaTratamientos";
            this.grdVistaTratamientos.RowHeadersWidth = 62;
            this.grdVistaTratamientos.RowTemplate.Height = 33;
            this.grdVistaTratamientos.Size = new System.Drawing.Size(816, 247);
            this.grdVistaTratamientos.TabIndex = 41;
            // 
            // idTratamiento
            // 
            this.idTratamiento.DataPropertyName = "ID_TRATAMIENTO";
            this.idTratamiento.HeaderText = "ID";
            this.idTratamiento.MinimumWidth = 8;
            this.idTratamiento.Name = "idTratamiento";
            this.idTratamiento.Width = 150;
            // 
            // idPadecimiento
            // 
            this.idPadecimiento.DataPropertyName = "ID_PADECIMIENTO";
            this.idPadecimiento.HeaderText = "ID Padecimiento";
            this.idPadecimiento.MinimumWidth = 8;
            this.idPadecimiento.Name = "idPadecimiento";
            this.idPadecimiento.Width = 150;
            // 
            // nombre
            // 
            this.nombre.DataPropertyName = "NOMBRE";
            this.nombre.HeaderText = "Nombre";
            this.nombre.MinimumWidth = 8;
            this.nombre.Name = "nombre";
            this.nombre.Width = 150;
            // 
            // dosis
            // 
            this.dosis.DataPropertyName = "DOSIS";
            this.dosis.HeaderText = "Dosis";
            this.dosis.MinimumWidth = 8;
            this.dosis.Name = "dosis";
            this.dosis.Width = 150;
            // 
            // duracion
            // 
            this.duracion.DataPropertyName = "DURACION";
            this.duracion.HeaderText = "Duración";
            this.duracion.MinimumWidth = 8;
            this.duracion.Name = "duracion";
            this.duracion.Width = 150;
            // 
            // estado
            // 
            this.estado.DataPropertyName = "ESTADO";
            this.estado.HeaderText = "Estado";
            this.estado.MinimumWidth = 8;
            this.estado.Name = "estado";
            this.estado.Width = 150;
            // 
            // btnGuardarTratamiento
            // 
            this.btnGuardarTratamiento.Location = new System.Drawing.Point(72, 747);
            this.btnGuardarTratamiento.Name = "btnGuardarTratamiento";
            this.btnGuardarTratamiento.Size = new System.Drawing.Size(166, 49);
            this.btnGuardarTratamiento.TabIndex = 40;
            this.btnGuardarTratamiento.Text = "Guardar";
            this.btnGuardarTratamiento.UseVisualStyleBackColor = true;
            this.btnGuardarTratamiento.Click += new System.EventHandler(this.btnGuardarTratamiento_Click);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(35, 64);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(187, 30);
            this.label13.TabIndex = 38;
            this.label13.Text = "ID Tratamiento";
            // 
            // txtIdTratamiento
            // 
            this.txtIdTratamiento.Enabled = false;
            this.txtIdTratamiento.Location = new System.Drawing.Point(274, 57);
            this.txtIdTratamiento.Name = "txtIdTratamiento";
            this.txtIdTratamiento.Size = new System.Drawing.Size(257, 37);
            this.txtIdTratamiento.TabIndex = 39;
            // 
            // frmTratamientos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(946, 887);
            this.Controls.Add(this.groupBox2);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmTratamientos";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Tratamientos";
            this.Load += new System.EventHandler(this.frmTratamientos_Load);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdVistaTratamientos)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txtDosis;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtNombre;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtIdPadecimiento;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnLimpiar;
        private System.Windows.Forms.Button btnSalir;
        private System.Windows.Forms.Button btnEliminar;
        private System.Windows.Forms.DataGridView grdVistaTratamientos;
        private System.Windows.Forms.Button btnGuardarTratamiento;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtIdTratamiento;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtDuracion;
        private System.Windows.Forms.DataGridViewTextBoxColumn idTratamiento;
        private System.Windows.Forms.DataGridViewTextBoxColumn idPadecimiento;
        private System.Windows.Forms.DataGridViewTextBoxColumn nombre;
        private System.Windows.Forms.DataGridViewTextBoxColumn dosis;
        private System.Windows.Forms.DataGridViewTextBoxColumn duracion;
        private System.Windows.Forms.DataGridViewTextBoxColumn estado;
        private System.Windows.Forms.ComboBox cboEstado;
    }
}