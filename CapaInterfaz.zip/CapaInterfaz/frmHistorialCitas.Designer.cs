﻿namespace CapaInterfaz
{
    partial class frmHistorialCitas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txtMotivo = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.dtpFecha = new System.Windows.Forms.DateTimePicker();
            this.txtIdMedico = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtHora = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtIdExpediente = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnLimpiar = new System.Windows.Forms.Button();
            this.btnSalir = new System.Windows.Forms.Button();
            this.btnEliminar = new System.Windows.Forms.Button();
            this.grdVistaHistorial = new System.Windows.Forms.DataGridView();
            this.idHistorial = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idExpediente = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fecha = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.hora = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idMedico = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.motivo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnGuardarHistorial = new System.Windows.Forms.Button();
            this.label13 = new System.Windows.Forms.Label();
            this.txtHistorialCita = new System.Windows.Forms.TextBox();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdVistaHistorial)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.txtMotivo);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.dtpFecha);
            this.groupBox2.Controls.Add(this.txtIdMedico);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.txtHora);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.txtIdExpediente);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.btnLimpiar);
            this.groupBox2.Controls.Add(this.btnSalir);
            this.groupBox2.Controls.Add(this.btnEliminar);
            this.groupBox2.Controls.Add(this.grdVistaHistorial);
            this.groupBox2.Controls.Add(this.btnGuardarHistorial);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.txtHistorialCita);
            this.groupBox2.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.groupBox2.Location = new System.Drawing.Point(35, 27);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(885, 808);
            this.groupBox2.TabIndex = 42;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Historial";
            // 
            // txtMotivo
            // 
            this.txtMotivo.Location = new System.Drawing.Point(274, 399);
            this.txtMotivo.Name = "txtMotivo";
            this.txtMotivo.Size = new System.Drawing.Size(257, 37);
            this.txtMotivo.TabIndex = 55;
            this.txtMotivo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtMotivo_KeyPress);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(35, 406);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(97, 30);
            this.label5.TabIndex = 54;
            this.label5.Text = "Motivo";
            // 
            // dtpFecha
            // 
            this.dtpFecha.Location = new System.Drawing.Point(274, 190);
            this.dtpFecha.Name = "dtpFecha";
            this.dtpFecha.Size = new System.Drawing.Size(257, 37);
            this.dtpFecha.TabIndex = 53;
            // 
            // txtIdMedico
            // 
            this.txtIdMedico.Location = new System.Drawing.Point(274, 331);
            this.txtIdMedico.Name = "txtIdMedico";
            this.txtIdMedico.Size = new System.Drawing.Size(257, 37);
            this.txtIdMedico.TabIndex = 52;
            this.txtIdMedico.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtIdMedico_KeyPress);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(35, 334);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(137, 30);
            this.label4.TabIndex = 51;
            this.label4.Text = "ID Médico";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(35, 266);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(68, 30);
            this.label3.TabIndex = 50;
            this.label3.Text = "Hora";
            // 
            // txtHora
            // 
            this.txtHora.Location = new System.Drawing.Point(274, 259);
            this.txtHora.Name = "txtHora";
            this.txtHora.Size = new System.Drawing.Size(257, 37);
            this.txtHora.TabIndex = 49;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(35, 197);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(88, 30);
            this.label2.TabIndex = 47;
            this.label2.Text = "Fecha";
            // 
            // txtIdExpediente
            // 
            this.txtIdExpediente.Location = new System.Drawing.Point(274, 122);
            this.txtIdExpediente.Name = "txtIdExpediente";
            this.txtIdExpediente.Size = new System.Drawing.Size(257, 37);
            this.txtIdExpediente.TabIndex = 46;
            this.txtIdExpediente.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtIdExpediente_KeyPress);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(35, 125);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(178, 30);
            this.label1.TabIndex = 45;
            this.label1.Text = "ID Expediente";
            // 
            // btnLimpiar
            // 
            this.btnLimpiar.Location = new System.Drawing.Point(634, 735);
            this.btnLimpiar.Name = "btnLimpiar";
            this.btnLimpiar.Size = new System.Drawing.Size(169, 49);
            this.btnLimpiar.TabIndex = 44;
            this.btnLimpiar.Text = "Limpiar";
            this.btnLimpiar.UseVisualStyleBackColor = true;
            this.btnLimpiar.Click += new System.EventHandler(this.btnLimpiar_Click);
            // 
            // btnSalir
            // 
            this.btnSalir.Location = new System.Drawing.Point(449, 735);
            this.btnSalir.Name = "btnSalir";
            this.btnSalir.Size = new System.Drawing.Size(166, 49);
            this.btnSalir.TabIndex = 43;
            this.btnSalir.Text = "Salir";
            this.btnSalir.UseVisualStyleBackColor = true;
            this.btnSalir.Click += new System.EventHandler(this.btnSalir_Click);
            // 
            // btnEliminar
            // 
            this.btnEliminar.Location = new System.Drawing.Point(263, 735);
            this.btnEliminar.Name = "btnEliminar";
            this.btnEliminar.Size = new System.Drawing.Size(166, 49);
            this.btnEliminar.TabIndex = 42;
            this.btnEliminar.Text = "Eliminar";
            this.btnEliminar.UseVisualStyleBackColor = true;
            // 
            // grdVistaHistorial
            // 
            this.grdVistaHistorial.AllowUserToAddRows = false;
            this.grdVistaHistorial.AllowUserToDeleteRows = false;
            this.grdVistaHistorial.AllowUserToResizeColumns = false;
            this.grdVistaHistorial.AllowUserToResizeRows = false;
            this.grdVistaHistorial.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grdVistaHistorial.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idHistorial,
            this.idExpediente,
            this.fecha,
            this.hora,
            this.idMedico,
            this.motivo});
            this.grdVistaHistorial.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.grdVistaHistorial.Location = new System.Drawing.Point(35, 467);
            this.grdVistaHistorial.Name = "grdVistaHistorial";
            this.grdVistaHistorial.RowHeadersWidth = 62;
            this.grdVistaHistorial.RowTemplate.Height = 33;
            this.grdVistaHistorial.Size = new System.Drawing.Size(816, 247);
            this.grdVistaHistorial.TabIndex = 41;
            // 
            // idHistorial
            // 
            this.idHistorial.DataPropertyName = "ID_HISTORIAL_CITAS";
            this.idHistorial.HeaderText = "ID";
            this.idHistorial.MinimumWidth = 8;
            this.idHistorial.Name = "idHistorial";
            this.idHistorial.Width = 150;
            // 
            // idExpediente
            // 
            this.idExpediente.DataPropertyName = "ID_EXPEDIENTE";
            this.idExpediente.HeaderText = "ID Expediente";
            this.idExpediente.MinimumWidth = 8;
            this.idExpediente.Name = "idExpediente";
            this.idExpediente.Width = 150;
            // 
            // fecha
            // 
            this.fecha.DataPropertyName = "FECHA";
            this.fecha.HeaderText = "Fecha";
            this.fecha.MinimumWidth = 8;
            this.fecha.Name = "fecha";
            this.fecha.Width = 150;
            // 
            // hora
            // 
            this.hora.DataPropertyName = "HORA";
            this.hora.HeaderText = "Hora";
            this.hora.MinimumWidth = 8;
            this.hora.Name = "hora";
            this.hora.Width = 150;
            // 
            // idMedico
            // 
            this.idMedico.DataPropertyName = "ID_MEDICO_RESPONSABLE";
            this.idMedico.HeaderText = "ID Médico";
            this.idMedico.MinimumWidth = 8;
            this.idMedico.Name = "idMedico";
            this.idMedico.Width = 150;
            // 
            // motivo
            // 
            this.motivo.DataPropertyName = "MOTIVO";
            this.motivo.HeaderText = "Motivo";
            this.motivo.MinimumWidth = 8;
            this.motivo.Name = "motivo";
            this.motivo.Width = 150;
            // 
            // btnGuardarHistorial
            // 
            this.btnGuardarHistorial.Location = new System.Drawing.Point(76, 735);
            this.btnGuardarHistorial.Name = "btnGuardarHistorial";
            this.btnGuardarHistorial.Size = new System.Drawing.Size(166, 49);
            this.btnGuardarHistorial.TabIndex = 40;
            this.btnGuardarHistorial.Text = "Guardar";
            this.btnGuardarHistorial.UseVisualStyleBackColor = true;
            this.btnGuardarHistorial.Click += new System.EventHandler(this.btnGuardarHistorial_Click);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(35, 64);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(37, 30);
            this.label13.TabIndex = 38;
            this.label13.Text = "ID";
            // 
            // txtHistorialCita
            // 
            this.txtHistorialCita.Enabled = false;
            this.txtHistorialCita.Location = new System.Drawing.Point(274, 57);
            this.txtHistorialCita.Name = "txtHistorialCita";
            this.txtHistorialCita.Size = new System.Drawing.Size(257, 37);
            this.txtHistorialCita.TabIndex = 39;
            // 
            // frmHistorialCitas
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(955, 865);
            this.Controls.Add(this.groupBox2);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmHistorialCitas";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Historial Citas";
            this.Load += new System.EventHandler(this.frmHistorialCitas_Load);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdVistaHistorial)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txtIdMedico;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtHora;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtIdExpediente;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnLimpiar;
        private System.Windows.Forms.Button btnSalir;
        private System.Windows.Forms.Button btnEliminar;
        private System.Windows.Forms.DataGridView grdVistaHistorial;
        private System.Windows.Forms.Button btnGuardarHistorial;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtHistorialCita;
        private System.Windows.Forms.DateTimePicker dtpFecha;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtMotivo;
        private System.Windows.Forms.DataGridViewTextBoxColumn idHistorial;
        private System.Windows.Forms.DataGridViewTextBoxColumn idExpediente;
        private System.Windows.Forms.DataGridViewTextBoxColumn fecha;
        private System.Windows.Forms.DataGridViewTextBoxColumn hora;
        private System.Windows.Forms.DataGridViewTextBoxColumn idMedico;
        private System.Windows.Forms.DataGridViewTextBoxColumn motivo;
    }
}