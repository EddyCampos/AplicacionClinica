﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CapaLogica;
using CapaEntidades;
using System.Data.Common;

namespace CapaInterfaz
{
    public partial class frmPacientes : Form
    {
        //Variable global del tipo del cliente que voy a abrir
        frmBuscarPacientes formlarioBuscar;

        //Variable global para un cliente
        EntidadPacientes pacienteRegistrado;

        string idPacienteSeleccionado = string.Empty;

        public frmPacientes()
        {
            InitializeComponent();
        }
        
        //Cierra el formulario
        private void btnSalir_Click_1(object sender, EventArgs e)
        {
            Close();
        }//Fin btnSalir_Click_1

        //Genera Entidad
        private EntidadPacientes GenerarEntidadPacientes()
        {
            EntidadPacientes paciente = new EntidadPacientes();

            paciente.SetNumCedula(txtCedula.Text);
            paciente.SetNombre(txtNombre.Text);
            paciente.SetApellido01(txtApellido1.Text);
            paciente.SetApellido02(txtApellido2.Text);
            paciente.SetPais(txtPais.Text);
            paciente.SetProvincia(cboProvincia.Text);
            paciente.SetSexo(cboSexo.Text);
            paciente.SetCorreoElectronico(txtCorreo.Text);
            paciente.SetFechaNacimiento(Convert.ToDateTime(dtpFnacimiento.Text));
            paciente.SetEstadoCivil(cboEstadoCivil.Text);
            paciente.SetNumTelefono(txtTelefono.Text);
            paciente.SetTipoSangre(txtTipoSangre.Text);
            paciente.SetEstado(cboEstado.Text);

            return paciente;
        }//Fin GenerarEntidadPacientes

        //Cancela el evento cuando se ingresan letras o simbolos, valida solo numeros
        public void ValidarSoloNum(object sender, KeyPressEventArgs e)
        {
            if (char.IsDigit(e.KeyChar) || e.KeyChar == 8)//TECLAS: NUMEROS Y BORRAR
            {
                //NO SE CANCELA EL EVENTO
                e.Handled = false;
            }
            else
            {
                //CANCELA EL EVENTO
                e.Handled = true;
            }
        }//Fin ValidarSoloNum

        //Cancela el evento cuando se ingresan numeros o simbolos, valida solo letras
        private void ValidarSoloTxt(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar) || e.KeyChar == 8 || e.KeyChar == 32)//TECLAS: LETRAS Y BORRAR
            {
                //NO SE CANCELA EL EVENTO
                e.Handled = false;
            }
            else
            {
                //CANCELA EL EVENTO
                e.Handled = true;
            }
        }//Fin ValidarSoloTxt

        //Guarda en la base de datos
        private void btnGuardarPacientes_Click(object sender, EventArgs e)
        {
            BLPacientes logica = new BLPacientes(Configuracion.getConnectionString);

            EntidadPacientes paciente;
            int resultado;

            try
            {
                if (!string.IsNullOrEmpty(txtNombre.Text) &&
                    !string.IsNullOrEmpty(txtCedula.Text) &&
                    !string.IsNullOrEmpty(txtApellido1.Text) &&
                    !string.IsNullOrEmpty(txtApellido2.Text) &&
                    !string.IsNullOrEmpty(txtPais.Text) &&
                    !string.IsNullOrEmpty(cboProvincia.Text) &&
                    !string.IsNullOrEmpty(cboSexo.Text) &&
                    !string.IsNullOrEmpty(dtpFnacimiento.Text) &&
                    !string.IsNullOrEmpty(cboEstadoCivil.Text) &&
                    !string.IsNullOrEmpty(txtTelefono.Text) &&
                    !string.IsNullOrEmpty(txtTipoSangre.Text) &&
                    !string.IsNullOrEmpty(cboEstado.Text))
                {
                    paciente = GenerarEntidadPacientes();

                    if (!paciente.GetExiste())
                    {
                        resultado = logica.InsertarPaciente(paciente);
                        MessageBox.Show("Paciente insertado Correctamente", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        resultado = logica.ModificarPacientes(paciente);
                        MessageBox.Show("Paciente actualizado Correctamente", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    limpiar();
                    CargarListaPacientes();
                    
                }
                else
                {
                    MessageBox.Show("Datos obligatorios", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }//btnGuardarPacientes_Click

        //Cargar la lista de clientes con un DATASET
        public void CargarListaPacientes(string condicion = "", string orden = "")
        {
            BLPacientes logica = new BLPacientes(Configuracion.getConnectionString);
            DataSet DSPacientes;

            try
            {
                DSPacientes = logica.ListarPacientes(condicion, orden);
                grdVistaPacientes.DataSource = DSPacientes;
                grdVistaPacientes.DataMember = DSPacientes.Tables["PACIENTES"].TableName;
            }
            catch (Exception)
            {

                MessageBox.Show("Ocurrió un error", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }//Fin CargarListaPacientes

        //Cuando carga el formulario que cargue la vista de la tabla
        private void frmPacientes_Load(object sender, EventArgs e)
        {
            try
            {
                CargarListaPacientes();
                btnExpediente.Enabled = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }//Fin frmPacientes_Load

        //Solo permite llenar el campo con numeros
        private void txtCedula_KeyPress(object sender, KeyPressEventArgs e)
        {
            ValidarSoloNum(sender, e);
        }

        //Solo permite llenar el campo con letras
        private void txtNombre_KeyPress(object sender, KeyPressEventArgs e)
        {
            ValidarSoloTxt(sender, e);
        }

        //Solo permite llenar el campo con letras
        private void txtApellido1_KeyPress(object sender, KeyPressEventArgs e)
        {
            ValidarSoloTxt(sender, e);
        }

        //Solo permite llenar el campo con letras
        private void txtApellido2_KeyPress(object sender, KeyPressEventArgs e)
        {
            ValidarSoloTxt(sender, e);
        }

        //Solo permite llenar el campo con letras
        private void txtPais_KeyPress(object sender, KeyPressEventArgs e)
        {
            ValidarSoloTxt(sender, e);
        }

        //Solo permite llenar el campo con numeros
        private void txtTelefono_KeyPress(object sender, KeyPressEventArgs e)
        {
            ValidarSoloNum(sender, e);
        }

        //Método cargar los datos del cliente recuperados por medio de la cedula del form Buscar
        private void CargarPacienteEncontrado(int id)
        {
            EntidadPacientes paciente = new EntidadPacientes();
            BLPacientes traerPaciente = new BLPacientes(Configuracion.getConnectionString);

            try
            {
                paciente = traerPaciente.ObtenerPaciente (id);
                if (paciente != null)
                {
                    txtIdPaciente.Text = paciente.GetIdPaciente().ToString();
                    txtCedula.Text = paciente.GetNumTelefono();
                    txtNombre.Text = paciente.GetNombre();
                    txtApellido1.Text = paciente.GetApellido01();
                    txtApellido2.Text = paciente.GetApellido02();
                    txtPais.Text = paciente.GetPais();
                    cboProvincia.Text = paciente.GetProvincia();
                    cboSexo.Text = paciente.GetSexo();
                    dtpFnacimiento.Text = paciente.GetFNacimiento().ToString();
                    cboEstadoCivil.Text = paciente.GetEstadoCivil();
                    txtCorreo.Text = paciente.GetCorreoElectronico();
                    txtTelefono.Text = paciente.GetNumTelefono();
                    txtTipoSangre.Text = paciente.GetTipoSangre();
                    cboEstado.Text = paciente.GetEstado();
                    pacienteRegistrado = paciente;

                    //Variable global mostrar info dl paciente
                    idPacienteSeleccionado = paciente.GetIdPaciente().ToString();
                    btnExpediente.Enabled = true;
                }
                else
                {
                    MessageBox.Show("Cliente no está en la BD", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    CargarListaPacientes();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }//Fin CargarCliente

        //Evento cuando se da click al boton de aceptar en el formulario de Buscar Paciente
        private void Aceptar(object id, EventArgs e)
        {
            try
            {
                int idPaciente = (int)id;
                if (idPaciente != -1)
                {
                    //MessageBox.Show(idCliente.ToString());
                    CargarPacienteEncontrado(idPaciente);
                }
                else
                {
                    //Limpiar();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }//Fin Aceptar

        //LLama al formulario que busca con el click al boton buscar
        private void btnBuscar_Click(object sender, EventArgs e)
        {
            formlarioBuscar = new frmBuscarPacientes();

            //Especificar que se va a usar el evento aceptar, eventhandler captura un evento
            formlarioBuscar.Aceptar += new EventHandler(Aceptar);

            //Que se esta abriendo de otro formulario
            formlarioBuscar.ShowDialog();
        }//Fin btnBuscar_Click

        //LLama al formulario que muestra el expediente
        private void btnExpediente_Click(object sender, EventArgs e)
        {
            frmExpedientes frm = new frmExpedientes(idPacienteSeleccionado);
            frm.ShowDialog();

        }//Fin btnExpediente_Click

        //Limpia info de los espacios
        private void limpiar()
        {
            txtIdPaciente.Text = string.Empty;
            txtCedula.Text = string.Empty;
            txtNombre.Text = string.Empty;
            txtApellido1.Text = string.Empty;
            txtApellido2.Text = string.Empty;
            txtPais.Text = string.Empty;
            cboProvincia.SelectedIndex = 0;
            cboSexo.SelectedIndex = 0;
            dtpFnacimiento.Value = Convert.ToDateTime("01/01/1900");
            cboEstadoCivil.SelectedIndex = 0;
            txtCorreo.Text = string.Empty;
            txtTipoSangre.Text = string.Empty;
            txtTelefono.Text = string.Empty;
            cboEstado.SelectedIndex = 0;

        }//Fin limpiar

        //Boton limpia todas las casillas
        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            limpiar();
        }//Fin btnLimpiar_Click

        //Si no selecciona un paciente desactiva el boton
        private void VerificarVerExpediente()
        {
            if(string.IsNullOrEmpty(txtIdPaciente.Text))
            {
                btnExpediente.Enabled = false;
            }
            else
            {
                btnExpediente.Enabled = true;
            }
        }//Fin VerificarVerExpediente

        //Cuando tiene un valor activa el boton del expedeitne
        private void txtIdPaciente_TextChanged(object sender, EventArgs e)
        {
            VerificarVerExpediente();
        }//Fin txtIdPaciente_TextChanged

    }//Fin clase frmPacientes : Form
}//Fin namespace
