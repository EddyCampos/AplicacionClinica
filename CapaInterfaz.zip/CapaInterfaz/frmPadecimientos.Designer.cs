﻿namespace CapaInterfaz
{
    partial class frmPadecimientos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.cboEstado = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtDescripcion = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtNombre = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtIdExpediente = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnLimpiar = new System.Windows.Forms.Button();
            this.btnSalir = new System.Windows.Forms.Button();
            this.btnEliminar = new System.Windows.Forms.Button();
            this.grdVistaPadecimientos = new System.Windows.Forms.DataGridView();
            this.idPadecimiento = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idExpediente = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nombre = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.descripcion = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.estado = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnGuardarPadecimiento = new System.Windows.Forms.Button();
            this.label13 = new System.Windows.Forms.Label();
            this.txtIdPadecimiento = new System.Windows.Forms.TextBox();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdVistaPadecimientos)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.cboEstado);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.txtDescripcion);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.txtNombre);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.txtIdExpediente);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.btnLimpiar);
            this.groupBox2.Controls.Add(this.btnSalir);
            this.groupBox2.Controls.Add(this.btnEliminar);
            this.groupBox2.Controls.Add(this.grdVistaPadecimientos);
            this.groupBox2.Controls.Add(this.btnGuardarPadecimiento);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.txtIdPadecimiento);
            this.groupBox2.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.groupBox2.Location = new System.Drawing.Point(33, 41);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(1049, 707);
            this.groupBox2.TabIndex = 42;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Padecimientos";
            // 
            // cboEstado
            // 
            this.cboEstado.FormattingEnabled = true;
            this.cboEstado.Items.AddRange(new object[] {
            "ACT",
            "INA"});
            this.cboEstado.Location = new System.Drawing.Point(753, 134);
            this.cboEstado.Name = "cboEstado";
            this.cboEstado.Size = new System.Drawing.Size(257, 38);
            this.cboEstado.TabIndex = 52;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(560, 142);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(92, 30);
            this.label4.TabIndex = 51;
            this.label4.Text = "Estado";
            // 
            // txtDescripcion
            // 
            this.txtDescripcion.Location = new System.Drawing.Point(274, 215);
            this.txtDescripcion.Multiline = true;
            this.txtDescripcion.Name = "txtDescripcion";
            this.txtDescripcion.Size = new System.Drawing.Size(736, 89);
            this.txtDescripcion.TabIndex = 50;
            this.txtDescripcion.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDescripcion_KeyPress);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(35, 246);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(155, 30);
            this.label3.TabIndex = 49;
            this.label3.Text = "Descripción";
            // 
            // txtNombre
            // 
            this.txtNombre.Location = new System.Drawing.Point(274, 135);
            this.txtNombre.Name = "txtNombre";
            this.txtNombre.Size = new System.Drawing.Size(257, 37);
            this.txtNombre.TabIndex = 48;
            this.txtNombre.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNombre_KeyPress);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(35, 142);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(110, 30);
            this.label2.TabIndex = 47;
            this.label2.Text = "Nombre";
            // 
            // txtIdExpediente
            // 
            this.txtIdExpediente.Location = new System.Drawing.Point(753, 61);
            this.txtIdExpediente.Name = "txtIdExpediente";
            this.txtIdExpediente.Size = new System.Drawing.Size(257, 37);
            this.txtIdExpediente.TabIndex = 46;
            this.txtIdExpediente.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtIdExpediente_KeyPress);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(560, 64);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(178, 30);
            this.label1.TabIndex = 45;
            this.label1.Text = "ID Expediente";
            // 
            // btnLimpiar
            // 
            this.btnLimpiar.Location = new System.Drawing.Point(717, 625);
            this.btnLimpiar.Name = "btnLimpiar";
            this.btnLimpiar.Size = new System.Drawing.Size(169, 49);
            this.btnLimpiar.TabIndex = 44;
            this.btnLimpiar.Text = "Limpiar";
            this.btnLimpiar.UseVisualStyleBackColor = true;
            this.btnLimpiar.Click += new System.EventHandler(this.btnLimpiar_Click);
            // 
            // btnSalir
            // 
            this.btnSalir.Location = new System.Drawing.Point(532, 625);
            this.btnSalir.Name = "btnSalir";
            this.btnSalir.Size = new System.Drawing.Size(166, 49);
            this.btnSalir.TabIndex = 43;
            this.btnSalir.Text = "Salir";
            this.btnSalir.UseVisualStyleBackColor = true;
            this.btnSalir.Click += new System.EventHandler(this.btnSalir_Click);
            // 
            // btnEliminar
            // 
            this.btnEliminar.Location = new System.Drawing.Point(346, 625);
            this.btnEliminar.Name = "btnEliminar";
            this.btnEliminar.Size = new System.Drawing.Size(166, 49);
            this.btnEliminar.TabIndex = 42;
            this.btnEliminar.Text = "Eliminar";
            this.btnEliminar.UseVisualStyleBackColor = true;
            // 
            // grdVistaPadecimientos
            // 
            this.grdVistaPadecimientos.AllowUserToAddRows = false;
            this.grdVistaPadecimientos.AllowUserToDeleteRows = false;
            this.grdVistaPadecimientos.AllowUserToResizeColumns = false;
            this.grdVistaPadecimientos.AllowUserToResizeRows = false;
            this.grdVistaPadecimientos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grdVistaPadecimientos.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idPadecimiento,
            this.idExpediente,
            this.nombre,
            this.descripcion,
            this.estado});
            this.grdVistaPadecimientos.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.grdVistaPadecimientos.Location = new System.Drawing.Point(35, 345);
            this.grdVistaPadecimientos.Name = "grdVistaPadecimientos";
            this.grdVistaPadecimientos.RowHeadersWidth = 62;
            this.grdVistaPadecimientos.RowTemplate.Height = 33;
            this.grdVistaPadecimientos.Size = new System.Drawing.Size(975, 247);
            this.grdVistaPadecimientos.TabIndex = 41;
            // 
            // idPadecimiento
            // 
            this.idPadecimiento.DataPropertyName = "ID_PADECIMIENTO";
            this.idPadecimiento.HeaderText = "ID";
            this.idPadecimiento.MinimumWidth = 8;
            this.idPadecimiento.Name = "idPadecimiento";
            this.idPadecimiento.Width = 150;
            // 
            // idExpediente
            // 
            this.idExpediente.DataPropertyName = "ID_EXPEDIENTE";
            this.idExpediente.HeaderText = "ID Expediente";
            this.idExpediente.MinimumWidth = 8;
            this.idExpediente.Name = "idExpediente";
            this.idExpediente.Width = 150;
            // 
            // nombre
            // 
            this.nombre.DataPropertyName = "NOMBRE";
            this.nombre.HeaderText = "Nombre";
            this.nombre.MinimumWidth = 8;
            this.nombre.Name = "nombre";
            this.nombre.Width = 150;
            // 
            // descripcion
            // 
            this.descripcion.DataPropertyName = "DESCRIPCION";
            this.descripcion.HeaderText = "Descripción";
            this.descripcion.MinimumWidth = 8;
            this.descripcion.Name = "descripcion";
            this.descripcion.Width = 300;
            // 
            // estado
            // 
            this.estado.DataPropertyName = "ESTADO";
            this.estado.HeaderText = "Estado";
            this.estado.MinimumWidth = 8;
            this.estado.Name = "estado";
            this.estado.Width = 150;
            // 
            // btnGuardarPadecimiento
            // 
            this.btnGuardarPadecimiento.Location = new System.Drawing.Point(159, 625);
            this.btnGuardarPadecimiento.Name = "btnGuardarPadecimiento";
            this.btnGuardarPadecimiento.Size = new System.Drawing.Size(166, 49);
            this.btnGuardarPadecimiento.TabIndex = 40;
            this.btnGuardarPadecimiento.Text = "Guardar";
            this.btnGuardarPadecimiento.UseVisualStyleBackColor = true;
            this.btnGuardarPadecimiento.Click += new System.EventHandler(this.btnGuardarPadecimiento_Click);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(35, 64);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(213, 30);
            this.label13.TabIndex = 38;
            this.label13.Text = "ID Padecimiento";
            // 
            // txtIdPadecimiento
            // 
            this.txtIdPadecimiento.Enabled = false;
            this.txtIdPadecimiento.Location = new System.Drawing.Point(274, 57);
            this.txtIdPadecimiento.Name = "txtIdPadecimiento";
            this.txtIdPadecimiento.Size = new System.Drawing.Size(257, 37);
            this.txtIdPadecimiento.TabIndex = 39;
            // 
            // frmPadecimientos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1130, 784);
            this.Controls.Add(this.groupBox2);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmPadecimientos";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Padecimientos";
            this.Load += new System.EventHandler(this.frmPadecimientos_Load);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdVistaPadecimientos)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.ComboBox cboEstado;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtDescripcion;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtNombre;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtIdExpediente;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnLimpiar;
        private System.Windows.Forms.Button btnSalir;
        private System.Windows.Forms.Button btnEliminar;
        private System.Windows.Forms.DataGridView grdVistaPadecimientos;
        private System.Windows.Forms.Button btnGuardarPadecimiento;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtIdPadecimiento;
        private System.Windows.Forms.DataGridViewTextBoxColumn idPadecimiento;
        private System.Windows.Forms.DataGridViewTextBoxColumn idExpediente;
        private System.Windows.Forms.DataGridViewTextBoxColumn nombre;
        private System.Windows.Forms.DataGridViewTextBoxColumn descripcion;
        private System.Windows.Forms.DataGridViewTextBoxColumn estado;
    }
}