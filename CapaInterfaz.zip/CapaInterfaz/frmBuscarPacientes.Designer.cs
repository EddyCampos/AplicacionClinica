﻿namespace CapaInterfaz
{
    partial class frmBuscarPacientes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txtCedula = new System.Windows.Forms.TextBox();
            this.btnBuscar = new System.Windows.Forms.Button();
            this.grdVistaPacientes = new System.Windows.Forms.DataGridView();
            this.idPaciente = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cedula = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nombre = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.primerApellido = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.segundoApellido = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pais = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.provincia = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sexo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fNacimiento = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.estadoCivil = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.email = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.telefono = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tipoSangre = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.estado = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnCancelar = new System.Windows.Forms.Button();
            this.btnAceptar = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.grdVistaPacientes)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(44, 57);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(102, 30);
            this.label1.TabIndex = 0;
            this.label1.Text = "Cédula";
            // 
            // txtCedula
            // 
            this.txtCedula.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.txtCedula.Location = new System.Drawing.Point(164, 57);
            this.txtCedula.Name = "txtCedula";
            this.txtCedula.Size = new System.Drawing.Size(293, 37);
            this.txtCedula.TabIndex = 1;
            this.txtCedula.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCedula_KeyPress);
            // 
            // btnBuscar
            // 
            this.btnBuscar.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnBuscar.Location = new System.Drawing.Point(942, 48);
            this.btnBuscar.Name = "btnBuscar";
            this.btnBuscar.Size = new System.Drawing.Size(147, 55);
            this.btnBuscar.TabIndex = 2;
            this.btnBuscar.Text = "Buscar";
            this.btnBuscar.UseVisualStyleBackColor = true;
            this.btnBuscar.Click += new System.EventHandler(this.btnBuscar_Click);
            // 
            // grdVistaPacientes
            // 
            this.grdVistaPacientes.AllowUserToAddRows = false;
            this.grdVistaPacientes.AllowUserToDeleteRows = false;
            this.grdVistaPacientes.AllowUserToResizeColumns = false;
            this.grdVistaPacientes.AllowUserToResizeRows = false;
            this.grdVistaPacientes.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grdVistaPacientes.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idPaciente,
            this.cedula,
            this.nombre,
            this.primerApellido,
            this.segundoApellido,
            this.pais,
            this.provincia,
            this.sexo,
            this.fNacimiento,
            this.estadoCivil,
            this.email,
            this.telefono,
            this.tipoSangre,
            this.estado});
            this.grdVistaPacientes.Location = new System.Drawing.Point(44, 130);
            this.grdVistaPacientes.Name = "grdVistaPacientes";
            this.grdVistaPacientes.RowHeadersWidth = 62;
            this.grdVistaPacientes.RowTemplate.Height = 33;
            this.grdVistaPacientes.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.grdVistaPacientes.Size = new System.Drawing.Size(1045, 259);
            this.grdVistaPacientes.TabIndex = 33;
            this.grdVistaPacientes.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.grdVistaPacientes_CellContentClick);
            // 
            // idPaciente
            // 
            this.idPaciente.DataPropertyName = "ID_PACIENTE";
            this.idPaciente.HeaderText = "ID";
            this.idPaciente.MinimumWidth = 8;
            this.idPaciente.Name = "idPaciente";
            this.idPaciente.ReadOnly = true;
            this.idPaciente.Width = 150;
            // 
            // cedula
            // 
            this.cedula.DataPropertyName = "NUM_CEDULA";
            this.cedula.HeaderText = "Cédula";
            this.cedula.MinimumWidth = 8;
            this.cedula.Name = "cedula";
            this.cedula.Width = 150;
            // 
            // nombre
            // 
            this.nombre.DataPropertyName = "NOMBRE";
            this.nombre.HeaderText = "Nombre";
            this.nombre.MinimumWidth = 8;
            this.nombre.Name = "nombre";
            this.nombre.Width = 150;
            // 
            // primerApellido
            // 
            this.primerApellido.DataPropertyName = "APELLIDO_01";
            this.primerApellido.HeaderText = "Primer Apellido";
            this.primerApellido.MinimumWidth = 8;
            this.primerApellido.Name = "primerApellido";
            this.primerApellido.Width = 150;
            // 
            // segundoApellido
            // 
            this.segundoApellido.DataPropertyName = "APELLIDO_02";
            this.segundoApellido.HeaderText = "Segundo Apellido";
            this.segundoApellido.MinimumWidth = 8;
            this.segundoApellido.Name = "segundoApellido";
            this.segundoApellido.Width = 150;
            // 
            // pais
            // 
            this.pais.DataPropertyName = "PAIS";
            this.pais.HeaderText = "País";
            this.pais.MinimumWidth = 8;
            this.pais.Name = "pais";
            this.pais.Width = 150;
            // 
            // provincia
            // 
            this.provincia.DataPropertyName = "PROVINCIA";
            this.provincia.HeaderText = "Provincia";
            this.provincia.MinimumWidth = 8;
            this.provincia.Name = "provincia";
            this.provincia.Width = 150;
            // 
            // sexo
            // 
            this.sexo.DataPropertyName = "SEXO";
            this.sexo.HeaderText = "Sexo";
            this.sexo.MinimumWidth = 8;
            this.sexo.Name = "sexo";
            this.sexo.Width = 150;
            // 
            // fNacimiento
            // 
            this.fNacimiento.DataPropertyName = "FECHA_NACIMIENTO";
            this.fNacimiento.HeaderText = "Fecha Nacimiento";
            this.fNacimiento.MinimumWidth = 8;
            this.fNacimiento.Name = "fNacimiento";
            this.fNacimiento.Width = 150;
            // 
            // estadoCivil
            // 
            this.estadoCivil.DataPropertyName = "ESTADO_CIVIL";
            this.estadoCivil.HeaderText = "Estado Civil";
            this.estadoCivil.MinimumWidth = 8;
            this.estadoCivil.Name = "estadoCivil";
            this.estadoCivil.Width = 150;
            // 
            // email
            // 
            this.email.DataPropertyName = "CORREO_ELECTRONICO";
            this.email.HeaderText = "Email";
            this.email.MinimumWidth = 8;
            this.email.Name = "email";
            this.email.Width = 150;
            // 
            // telefono
            // 
            this.telefono.DataPropertyName = "NUM_TELEFONO";
            this.telefono.HeaderText = "Teléfono";
            this.telefono.MinimumWidth = 8;
            this.telefono.Name = "telefono";
            this.telefono.Width = 150;
            // 
            // tipoSangre
            // 
            this.tipoSangre.DataPropertyName = "TIPO_SANGRE";
            this.tipoSangre.HeaderText = "Tipo Sangre";
            this.tipoSangre.MinimumWidth = 8;
            this.tipoSangre.Name = "tipoSangre";
            this.tipoSangre.Width = 150;
            // 
            // estado
            // 
            this.estado.DataPropertyName = "ESTADO";
            this.estado.HeaderText = "Estado";
            this.estado.MinimumWidth = 8;
            this.estado.Name = "estado";
            this.estado.Width = 150;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.btnCancelar);
            this.groupBox1.Controls.Add(this.btnAceptar);
            this.groupBox1.Controls.Add(this.grdVistaPacientes);
            this.groupBox1.Controls.Add(this.btnBuscar);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.txtCedula);
            this.groupBox1.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.groupBox1.Location = new System.Drawing.Point(24, 28);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1135, 503);
            this.groupBox1.TabIndex = 34;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Buscar";
            // 
            // btnCancelar
            // 
            this.btnCancelar.Location = new System.Drawing.Point(942, 417);
            this.btnCancelar.Name = "btnCancelar";
            this.btnCancelar.Size = new System.Drawing.Size(147, 55);
            this.btnCancelar.TabIndex = 35;
            this.btnCancelar.Text = "Cancelar";
            this.btnCancelar.UseVisualStyleBackColor = true;
            this.btnCancelar.Click += new System.EventHandler(this.btnCancelar_Click);
            // 
            // btnAceptar
            // 
            this.btnAceptar.Location = new System.Drawing.Point(741, 417);
            this.btnAceptar.Name = "btnAceptar";
            this.btnAceptar.Size = new System.Drawing.Size(147, 55);
            this.btnAceptar.TabIndex = 34;
            this.btnAceptar.Text = "Aceptar";
            this.btnAceptar.UseVisualStyleBackColor = true;
            this.btnAceptar.Click += new System.EventHandler(this.btnAceptar_Click);
            // 
            // frmBuscarPacientes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1201, 569);
            this.Controls.Add(this.groupBox1);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmBuscarPacientes";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Buscar Pacientes";
            this.Load += new System.EventHandler(this.frmBuscarPacientes_Load);
            ((System.ComponentModel.ISupportInitialize)(this.grdVistaPacientes)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtCedula;
        private System.Windows.Forms.Button btnBuscar;
        private System.Windows.Forms.DataGridView grdVistaPacientes;
        private System.Windows.Forms.DataGridViewTextBoxColumn idPaciente;
        private System.Windows.Forms.DataGridViewTextBoxColumn cedula;
        private System.Windows.Forms.DataGridViewTextBoxColumn nombre;
        private System.Windows.Forms.DataGridViewTextBoxColumn primerApellido;
        private System.Windows.Forms.DataGridViewTextBoxColumn segundoApellido;
        private System.Windows.Forms.DataGridViewTextBoxColumn pais;
        private System.Windows.Forms.DataGridViewTextBoxColumn provincia;
        private System.Windows.Forms.DataGridViewTextBoxColumn sexo;
        private System.Windows.Forms.DataGridViewTextBoxColumn fNacimiento;
        private System.Windows.Forms.DataGridViewTextBoxColumn estadoCivil;
        private System.Windows.Forms.DataGridViewTextBoxColumn email;
        private System.Windows.Forms.DataGridViewTextBoxColumn telefono;
        private System.Windows.Forms.DataGridViewTextBoxColumn tipoSangre;
        private System.Windows.Forms.DataGridViewTextBoxColumn estado;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnCancelar;
        private System.Windows.Forms.Button btnAceptar;
    }
}