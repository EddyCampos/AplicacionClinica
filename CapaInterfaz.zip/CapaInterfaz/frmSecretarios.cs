﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using CapaAccesoDatos;
using CapaEntidades;
using CapaLogica;

namespace CapaInterfaz
{
    public partial class frmSecretarios : Form
    {
        public frmSecretarios()
        {
            InitializeComponent();
        }

        //Cierra el formulario
        private void btnSalir_Click(object sender, EventArgs e)
        {
            Close();
        }//Fin btnSalir_Click

        //Genera Entidad Secretarios
        private EntidadSecretarios GenerarEntidadSecretario()
        {
            EntidadSecretarios secretario = new EntidadSecretarios();

            secretario.SetIdEmpleado(Convert.ToInt32(txtIdEmpleado.Text));

            return secretario;
        }//Fin GenerarEntidadSecretario

        //Guarda base de datos
        private void btnGuardarSecretario_Click(object sender, EventArgs e)
        {
            BLSecretarios logica = new BLSecretarios(Configuracion.getConnectionString);

            EntidadSecretarios secretario;
            int resultado;

            try
            {
                if (!string.IsNullOrEmpty(txtIdEmpleado.Text))
                {
                    secretario = GenerarEntidadSecretario();
                    resultado = logica.InsertarSecretario(secretario);
                    MessageBox.Show("Secretario insertado Correctamente", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    limpiar();
                    CargarListaSecretarios();
                }
                else
                {
                    MessageBox.Show("Datos obligatorios", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }//Fin btnGuardarSecretario_Click

        //Cargar la lista de clientes con un DATASET
        public void CargarListaSecretarios(string condicion = "", string orden = "")
        {
            BLSecretarios logica = new BLSecretarios(Configuracion.getConnectionString);
            DataSet DSSecretarios;

            try
            {
                DSSecretarios = logica.ListarSecretarios(condicion, orden);
                grdVistaSecretarios.DataSource = DSSecretarios;
                grdVistaSecretarios.DataMember = DSSecretarios.Tables["SECRETARIOS"].TableName;
            }
            catch (Exception)
            {

                MessageBox.Show("Ocurrió un error", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }//Fin CargarListaEmpleados

        //Cuando carga el formulario que cargue la vista de la tabla
        private void frmSecretarios_Load(object sender, EventArgs e)
        {
            try
            {
                CargarListaSecretarios();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }//Fin frmSecretarios_Load

        //Limpia info de los espacios
        private void limpiar()
        {
            txtIdSecretario.Text = string.Empty;
            txtIdEmpleado.Text = string.Empty;
        }//Fin limpiar

        //Boton limpia todas las casillas
        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            limpiar();
        }//Fin btnLimpiar_Click

        //Cancela el evento cuando se ingresan letras o simbolos, valida solo numeros
        public void ValidarSoloNum(object sender, KeyPressEventArgs e)
        {
            if (char.IsDigit(e.KeyChar) || e.KeyChar == 8)//TECLAS: NUMEROS Y BORRAR
            {
                //NO SE CANCELA EL EVENTO
                e.Handled = false;
            }
            else
            {
                //CANCELA EL EVENTO
                e.Handled = true;
            }
        }//Fin ValidarSoloNum

        //Solo permite llenar el campo con numeros
        private void txtIdEmpleado_KeyPress(object sender, KeyPressEventArgs e)
        {
            ValidarSoloNum(sender, e);
        }
    }//Fin clase frmSecretarios : Form
}//Fin namespace
