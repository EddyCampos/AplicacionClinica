﻿namespace CapaInterfaz
{
    partial class frmPlanillas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txtSalarioTotal = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtDeducciones = new System.Windows.Forms.TextBox();
            this.txtExtras = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtSalarioBruto = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtIdEmpleado = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnLimpiar = new System.Windows.Forms.Button();
            this.btnSalir = new System.Windows.Forms.Button();
            this.btnEliminar = new System.Windows.Forms.Button();
            this.grdVistaPlanillas = new System.Windows.Forms.DataGridView();
            this.idPlanilla = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idEmpleado = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.salarioBruto = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.extras = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.deducciones = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.salarioTotal = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnGuardarPlanilla = new System.Windows.Forms.Button();
            this.label13 = new System.Windows.Forms.Label();
            this.txtIdPlanilla = new System.Windows.Forms.TextBox();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdVistaPlanillas)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.txtSalarioTotal);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.txtDeducciones);
            this.groupBox2.Controls.Add(this.txtExtras);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.txtSalarioBruto);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.txtIdEmpleado);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.btnLimpiar);
            this.groupBox2.Controls.Add(this.btnSalir);
            this.groupBox2.Controls.Add(this.btnEliminar);
            this.groupBox2.Controls.Add(this.grdVistaPlanillas);
            this.groupBox2.Controls.Add(this.btnGuardarPlanilla);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.txtIdPlanilla);
            this.groupBox2.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.groupBox2.Location = new System.Drawing.Point(36, 31);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(885, 825);
            this.groupBox2.TabIndex = 42;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Planilla";
            // 
            // txtSalarioTotal
            // 
            this.txtSalarioTotal.Location = new System.Drawing.Point(274, 397);
            this.txtSalarioTotal.Name = "txtSalarioTotal";
            this.txtSalarioTotal.Size = new System.Drawing.Size(257, 37);
            this.txtSalarioTotal.TabIndex = 55;
            this.txtSalarioTotal.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtSalarioTotal_KeyPress);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(35, 404);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(156, 30);
            this.label5.TabIndex = 54;
            this.label5.Text = "Salario Total";
            // 
            // txtDeducciones
            // 
            this.txtDeducciones.Location = new System.Drawing.Point(274, 327);
            this.txtDeducciones.Name = "txtDeducciones";
            this.txtDeducciones.Size = new System.Drawing.Size(257, 37);
            this.txtDeducciones.TabIndex = 53;
            this.txtDeducciones.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDeducciones_KeyPress);
            // 
            // txtExtras
            // 
            this.txtExtras.Location = new System.Drawing.Point(274, 259);
            this.txtExtras.Name = "txtExtras";
            this.txtExtras.Size = new System.Drawing.Size(257, 37);
            this.txtExtras.TabIndex = 52;
            this.txtExtras.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtExtras_KeyPress);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(35, 334);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(173, 30);
            this.label4.TabIndex = 51;
            this.label4.Text = "Deducciones";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(35, 266);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(79, 30);
            this.label3.TabIndex = 50;
            this.label3.Text = "Extras";
            // 
            // txtSalarioBruto
            // 
            this.txtSalarioBruto.Location = new System.Drawing.Point(274, 190);
            this.txtSalarioBruto.Name = "txtSalarioBruto";
            this.txtSalarioBruto.Size = new System.Drawing.Size(257, 37);
            this.txtSalarioBruto.TabIndex = 49;
            this.txtSalarioBruto.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtSalarioBruto_KeyPress);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(35, 197);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(159, 30);
            this.label2.TabIndex = 47;
            this.label2.Text = "Salario Bruto";
            // 
            // txtIdEmpleado
            // 
            this.txtIdEmpleado.Location = new System.Drawing.Point(274, 122);
            this.txtIdEmpleado.Name = "txtIdEmpleado";
            this.txtIdEmpleado.Size = new System.Drawing.Size(257, 37);
            this.txtIdEmpleado.TabIndex = 46;
            this.txtIdEmpleado.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtIdEmpleado_KeyPress);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(35, 125);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(167, 30);
            this.label1.TabIndex = 45;
            this.label1.Text = "ID Empleado";
            // 
            // btnLimpiar
            // 
            this.btnLimpiar.Location = new System.Drawing.Point(634, 757);
            this.btnLimpiar.Name = "btnLimpiar";
            this.btnLimpiar.Size = new System.Drawing.Size(169, 49);
            this.btnLimpiar.TabIndex = 44;
            this.btnLimpiar.Text = "Limpiar";
            this.btnLimpiar.UseVisualStyleBackColor = true;
            this.btnLimpiar.Click += new System.EventHandler(this.btnLimpiar_Click);
            // 
            // btnSalir
            // 
            this.btnSalir.Location = new System.Drawing.Point(449, 757);
            this.btnSalir.Name = "btnSalir";
            this.btnSalir.Size = new System.Drawing.Size(166, 49);
            this.btnSalir.TabIndex = 43;
            this.btnSalir.Text = "Salir";
            this.btnSalir.UseVisualStyleBackColor = true;
            this.btnSalir.Click += new System.EventHandler(this.btnSalir_Click);
            // 
            // btnEliminar
            // 
            this.btnEliminar.Location = new System.Drawing.Point(263, 757);
            this.btnEliminar.Name = "btnEliminar";
            this.btnEliminar.Size = new System.Drawing.Size(166, 49);
            this.btnEliminar.TabIndex = 42;
            this.btnEliminar.Text = "Eliminar";
            this.btnEliminar.UseVisualStyleBackColor = true;
            // 
            // grdVistaPlanillas
            // 
            this.grdVistaPlanillas.AllowUserToAddRows = false;
            this.grdVistaPlanillas.AllowUserToDeleteRows = false;
            this.grdVistaPlanillas.AllowUserToResizeColumns = false;
            this.grdVistaPlanillas.AllowUserToResizeRows = false;
            this.grdVistaPlanillas.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grdVistaPlanillas.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idPlanilla,
            this.idEmpleado,
            this.salarioBruto,
            this.extras,
            this.deducciones,
            this.salarioTotal});
            this.grdVistaPlanillas.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.grdVistaPlanillas.Location = new System.Drawing.Point(35, 478);
            this.grdVistaPlanillas.Name = "grdVistaPlanillas";
            this.grdVistaPlanillas.RowHeadersWidth = 62;
            this.grdVistaPlanillas.RowTemplate.Height = 33;
            this.grdVistaPlanillas.Size = new System.Drawing.Size(816, 247);
            this.grdVistaPlanillas.TabIndex = 41;
            // 
            // idPlanilla
            // 
            this.idPlanilla.DataPropertyName = "ID_PLANILLA";
            this.idPlanilla.HeaderText = "ID";
            this.idPlanilla.MinimumWidth = 8;
            this.idPlanilla.Name = "idPlanilla";
            this.idPlanilla.Width = 150;
            // 
            // idEmpleado
            // 
            this.idEmpleado.DataPropertyName = "ID_EMPLEADO";
            this.idEmpleado.HeaderText = "ID Empleado";
            this.idEmpleado.MinimumWidth = 8;
            this.idEmpleado.Name = "idEmpleado";
            this.idEmpleado.Width = 150;
            // 
            // salarioBruto
            // 
            this.salarioBruto.DataPropertyName = "SALARIO_BRUTO";
            this.salarioBruto.HeaderText = "Salario Bruto";
            this.salarioBruto.MinimumWidth = 8;
            this.salarioBruto.Name = "salarioBruto";
            this.salarioBruto.Width = 150;
            // 
            // extras
            // 
            this.extras.DataPropertyName = "EXTRAS";
            this.extras.HeaderText = "Extras";
            this.extras.MinimumWidth = 8;
            this.extras.Name = "extras";
            this.extras.Width = 150;
            // 
            // deducciones
            // 
            this.deducciones.DataPropertyName = "DEDUCCIONES";
            this.deducciones.HeaderText = "Deducciones";
            this.deducciones.MinimumWidth = 8;
            this.deducciones.Name = "deducciones";
            this.deducciones.Width = 150;
            // 
            // salarioTotal
            // 
            this.salarioTotal.DataPropertyName = "SALARIO_TOTAL";
            this.salarioTotal.HeaderText = "Salario Total";
            this.salarioTotal.MinimumWidth = 8;
            this.salarioTotal.Name = "salarioTotal";
            this.salarioTotal.Width = 150;
            // 
            // btnGuardarPlanilla
            // 
            this.btnGuardarPlanilla.Location = new System.Drawing.Point(76, 757);
            this.btnGuardarPlanilla.Name = "btnGuardarPlanilla";
            this.btnGuardarPlanilla.Size = new System.Drawing.Size(166, 49);
            this.btnGuardarPlanilla.TabIndex = 40;
            this.btnGuardarPlanilla.Text = "Guardar";
            this.btnGuardarPlanilla.UseVisualStyleBackColor = true;
            this.btnGuardarPlanilla.Click += new System.EventHandler(this.btnGuardarPlanilla_Click);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(35, 64);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(129, 30);
            this.label13.TabIndex = 38;
            this.label13.Text = "ID Planilla";
            // 
            // txtIdPlanilla
            // 
            this.txtIdPlanilla.Enabled = false;
            this.txtIdPlanilla.Location = new System.Drawing.Point(274, 57);
            this.txtIdPlanilla.Name = "txtIdPlanilla";
            this.txtIdPlanilla.Size = new System.Drawing.Size(257, 37);
            this.txtIdPlanilla.TabIndex = 39;
            // 
            // frmPlanillas
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(956, 868);
            this.Controls.Add(this.groupBox2);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmPlanillas";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Planillas";
            this.Load += new System.EventHandler(this.frmPlanillas_Load);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdVistaPlanillas)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txtExtras;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtSalarioBruto;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtIdEmpleado;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnLimpiar;
        private System.Windows.Forms.Button btnSalir;
        private System.Windows.Forms.Button btnEliminar;
        private System.Windows.Forms.DataGridView grdVistaPlanillas;
        private System.Windows.Forms.Button btnGuardarPlanilla;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtIdPlanilla;
        private System.Windows.Forms.TextBox txtDeducciones;
        private System.Windows.Forms.TextBox txtSalarioTotal;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DataGridViewTextBoxColumn idPlanilla;
        private System.Windows.Forms.DataGridViewTextBoxColumn idEmpleado;
        private System.Windows.Forms.DataGridViewTextBoxColumn salarioBruto;
        private System.Windows.Forms.DataGridViewTextBoxColumn extras;
        private System.Windows.Forms.DataGridViewTextBoxColumn deducciones;
        private System.Windows.Forms.DataGridViewTextBoxColumn salarioTotal;
    }
}