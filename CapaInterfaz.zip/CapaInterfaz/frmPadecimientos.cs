﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using CapaEntidades;
using CapaLogica;
using static System.Windows.Forms.MonthCalendar;

namespace CapaInterfaz
{
    public partial class frmPadecimientos : Form
    {
        public frmPadecimientos()
        {
            InitializeComponent();
        }

        //Recibe el id del paciente
        private int idPacienteSeleccionado;
        public frmPadecimientos(int idPacienteSeleccionado)
        {
            InitializeComponent();
            this.idPacienteSeleccionado = idPacienteSeleccionado;
        }


        //Cierra el formulario
        private void btnSalir_Click(object sender, EventArgs e)
        {
            Close();
        }//Fin btnSalir_Click

        //Generar entidad
        private EntidadPadecimientos GenerarEntidadPadecimientos()
        {
            EntidadPadecimientos padecimiento = new EntidadPadecimientos();

            padecimiento.SetIdExpediente(Convert.ToInt32(txtIdExpediente.Text));
            padecimiento.SetNombre(txtNombre.Text);
            padecimiento.SetDescripcion(txtDescripcion.Text);
            padecimiento.SetEstado(cboEstado.Text);
            return padecimiento;
        }//Fin EntidadPadecimientos

        //Guarda en la base de datos
        private void btnGuardarPadecimiento_Click(object sender, EventArgs e)
        {
            BLPadecimientos logica = new BLPadecimientos(Configuracion.getConnectionString);

            EntidadPadecimientos padecimiento;
            int resultado;

            try
            {
                if (!string.IsNullOrEmpty(txtIdExpediente.Text) &&
                    !string.IsNullOrEmpty(txtNombre.Text) &&
                    !string.IsNullOrEmpty(txtDescripcion.Text) &&
                    !string.IsNullOrEmpty(cboEstado.Text))          
                {
                    padecimiento = GenerarEntidadPadecimientos();
                    resultado = logica.InsertarPadecimiento(padecimiento);
                    MessageBox.Show("Padecimiento insertado Correctamente", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    limpiar();
                    CargarListaPadecimientos();
                }
                else
                {
                    MessageBox.Show("Datos obligatorios", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }//Fin btnGuardarPadecimiento_Click

        //Cargar la lista de clientes con un DATASET
        public void CargarListaPadecimientos(string condicion = "", string orden = "")
        {
            BLPadecimientos logica = new BLPadecimientos(Configuracion.getConnectionString);
            DataSet DSPadecimientos;

            try
            {
                DSPadecimientos = logica.ListarPadecimientos(condicion, orden);
                grdVistaPadecimientos.DataSource = DSPadecimientos;
                grdVistaPadecimientos.DataMember = DSPadecimientos.Tables["PADECIMIENTOS"].TableName;
            }
            catch (Exception)
            {

                MessageBox.Show("Ocurrió un error", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }//Fin CargarListaMedicos

        //Cuando carga el formulario que cargue la vista de la tabla
        private void frmPadecimientos_Load(object sender, EventArgs e)
        {
            try
            {
                CargarListaPadecimientos();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }//Fin frmPadecimientos_Load

        //Limpia info de los espacios
        private void limpiar()
        {
            txtIdPadecimiento.Text = string.Empty;
            txtIdExpediente.Text = string.Empty;
            txtNombre.Text = string.Empty;
            txtDescripcion.Text = string.Empty;
            cboEstado.SelectedIndex = 0;
        }//Fin limpiar

        //Boton limpia todas las casillas
        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            limpiar();
        }//Fin btnLimpiar_Click

        //Cancela el evento cuando se ingresan letras o simbolos, valida solo numeros
        public void ValidarSoloNum(object sender, KeyPressEventArgs e)
        {
            if (char.IsDigit(e.KeyChar) || e.KeyChar == 8)//TECLAS: NUMEROS Y BORRAR
            {
                //NO SE CANCELA EL EVENTO
                e.Handled = false;
            }
            else
            {
                //CANCELA EL EVENTO
                e.Handled = true;
            }
        }//Fin ValidarSoloNum

        //Cancela el evento cuando se ingresan numeros o simbolos, valida solo letras
        private void ValidarSoloTxt(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar) || e.KeyChar == 8 || e.KeyChar == 32)//TECLAS: LETRAS Y BORRAR
            {
                //NO SE CANCELA EL EVENTO
                e.Handled = false;
            }
            else
            {
                //CANCELA EL EVENTO
                e.Handled = true;
            }
        }//Fin ValidarSoloTxt

        //Solo permite llenar el campo con numeros
        private void txtIdExpediente_KeyPress(object sender, KeyPressEventArgs e)
        {
            ValidarSoloNum(sender, e);
        }

        //Solo permite llenar el campo con letras
        private void txtNombre_KeyPress(object sender, KeyPressEventArgs e)
        {
            ValidarSoloTxt(sender, e);
        }

        //Solo permite llenar el campo con letras
        private void txtDescripcion_KeyPress(object sender, KeyPressEventArgs e)
        {
            ValidarSoloTxt(sender, e);
        }
    }//Fin clase frmPadecimientos : Form
}//Fin namespace
