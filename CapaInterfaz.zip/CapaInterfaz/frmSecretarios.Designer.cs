﻿namespace CapaInterfaz
{
    partial class frmSecretarios
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txtIdEmpleado = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnLimpiar = new System.Windows.Forms.Button();
            this.btnSalir = new System.Windows.Forms.Button();
            this.btnEliminar = new System.Windows.Forms.Button();
            this.grdVistaSecretarios = new System.Windows.Forms.DataGridView();
            this.ID_SECRETARIO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idEmpleado = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnGuardarSecretario = new System.Windows.Forms.Button();
            this.label13 = new System.Windows.Forms.Label();
            this.txtIdSecretario = new System.Windows.Forms.TextBox();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdVistaSecretarios)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.txtIdEmpleado);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.btnLimpiar);
            this.groupBox2.Controls.Add(this.btnSalir);
            this.groupBox2.Controls.Add(this.btnEliminar);
            this.groupBox2.Controls.Add(this.grdVistaSecretarios);
            this.groupBox2.Controls.Add(this.btnGuardarSecretario);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.txtIdSecretario);
            this.groupBox2.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.groupBox2.Location = new System.Drawing.Point(32, 30);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(775, 554);
            this.groupBox2.TabIndex = 39;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Secretario (a)";
            // 
            // txtIdEmpleado
            // 
            this.txtIdEmpleado.Location = new System.Drawing.Point(220, 122);
            this.txtIdEmpleado.Name = "txtIdEmpleado";
            this.txtIdEmpleado.Size = new System.Drawing.Size(257, 37);
            this.txtIdEmpleado.TabIndex = 46;
            this.txtIdEmpleado.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtIdEmpleado_KeyPress);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(35, 125);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(167, 30);
            this.label1.TabIndex = 45;
            this.label1.Text = "ID Empleado";
            // 
            // btnLimpiar
            // 
            this.btnLimpiar.Location = new System.Drawing.Point(582, 472);
            this.btnLimpiar.Name = "btnLimpiar";
            this.btnLimpiar.Size = new System.Drawing.Size(169, 49);
            this.btnLimpiar.TabIndex = 44;
            this.btnLimpiar.Text = "Limpiar";
            this.btnLimpiar.UseVisualStyleBackColor = true;
            this.btnLimpiar.Click += new System.EventHandler(this.btnLimpiar_Click);
            // 
            // btnSalir
            // 
            this.btnSalir.Location = new System.Drawing.Point(397, 472);
            this.btnSalir.Name = "btnSalir";
            this.btnSalir.Size = new System.Drawing.Size(166, 49);
            this.btnSalir.TabIndex = 43;
            this.btnSalir.Text = "Salir";
            this.btnSalir.UseVisualStyleBackColor = true;
            this.btnSalir.Click += new System.EventHandler(this.btnSalir_Click);
            // 
            // btnEliminar
            // 
            this.btnEliminar.Location = new System.Drawing.Point(211, 472);
            this.btnEliminar.Name = "btnEliminar";
            this.btnEliminar.Size = new System.Drawing.Size(166, 49);
            this.btnEliminar.TabIndex = 42;
            this.btnEliminar.Text = "Eliminar";
            this.btnEliminar.UseVisualStyleBackColor = true;
            // 
            // grdVistaSecretarios
            // 
            this.grdVistaSecretarios.AllowUserToAddRows = false;
            this.grdVistaSecretarios.AllowUserToDeleteRows = false;
            this.grdVistaSecretarios.AllowUserToResizeColumns = false;
            this.grdVistaSecretarios.AllowUserToResizeRows = false;
            this.grdVistaSecretarios.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grdVistaSecretarios.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ID_SECRETARIO,
            this.idEmpleado});
            this.grdVistaSecretarios.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.grdVistaSecretarios.Location = new System.Drawing.Point(144, 194);
            this.grdVistaSecretarios.Name = "grdVistaSecretarios";
            this.grdVistaSecretarios.RowHeadersWidth = 62;
            this.grdVistaSecretarios.RowTemplate.Height = 33;
            this.grdVistaSecretarios.Size = new System.Drawing.Size(514, 247);
            this.grdVistaSecretarios.TabIndex = 41;
            // 
            // ID_SECRETARIO
            // 
            this.ID_SECRETARIO.DataPropertyName = "ID_SECRETARIO";
            this.ID_SECRETARIO.HeaderText = "ID";
            this.ID_SECRETARIO.MinimumWidth = 8;
            this.ID_SECRETARIO.Name = "ID_SECRETARIO";
            this.ID_SECRETARIO.ReadOnly = true;
            this.ID_SECRETARIO.Width = 150;
            // 
            // idEmpleado
            // 
            this.idEmpleado.DataPropertyName = "ID_EMPLEADO";
            this.idEmpleado.HeaderText = "ID Empleado";
            this.idEmpleado.MinimumWidth = 8;
            this.idEmpleado.Name = "idEmpleado";
            this.idEmpleado.Width = 300;
            // 
            // btnGuardarSecretario
            // 
            this.btnGuardarSecretario.Location = new System.Drawing.Point(24, 472);
            this.btnGuardarSecretario.Name = "btnGuardarSecretario";
            this.btnGuardarSecretario.Size = new System.Drawing.Size(166, 49);
            this.btnGuardarSecretario.TabIndex = 40;
            this.btnGuardarSecretario.Text = "Guardar";
            this.btnGuardarSecretario.UseVisualStyleBackColor = true;
            this.btnGuardarSecretario.Click += new System.EventHandler(this.btnGuardarSecretario_Click);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(35, 64);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(164, 30);
            this.label13.TabIndex = 38;
            this.label13.Text = "ID Secretario";
            // 
            // txtIdSecretario
            // 
            this.txtIdSecretario.Enabled = false;
            this.txtIdSecretario.Location = new System.Drawing.Point(220, 57);
            this.txtIdSecretario.Name = "txtIdSecretario";
            this.txtIdSecretario.Size = new System.Drawing.Size(257, 37);
            this.txtIdSecretario.TabIndex = 39;
            // 
            // frmSecretarios
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(839, 613);
            this.Controls.Add(this.groupBox2);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmSecretarios";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Secretarios";
            this.Load += new System.EventHandler(this.frmSecretarios_Load);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdVistaSecretarios)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtIdSecretario;
        private System.Windows.Forms.DataGridView grdVistaSecretarios;
        private System.Windows.Forms.Button btnGuardarSecretario;
        private System.Windows.Forms.Button btnEliminar;
        private System.Windows.Forms.Button btnSalir;
        private System.Windows.Forms.Button btnLimpiar;
        private System.Windows.Forms.TextBox txtIdEmpleado;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID_SECRETARIO;
        private System.Windows.Forms.DataGridViewTextBoxColumn idEmpleado;
    }
}