﻿using CapaLogica;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace CapaInterfaz
{
    public partial class frmBuscarPacientes : Form
    {
        //Variable global del evento EventHandler para enviar valores
        public event EventHandler Aceptar;

        //Variable global del idCliente para acceder de todos métodos
        int vgn_idCliente;

        public frmBuscarPacientes()
        {
            InitializeComponent();
        }

        //Cargar la lista de clientes con un DATASET
        public void CargarListaPacientes(string condicion = "", string orden = "")
        {
            BLPacientes logica = new BLPacientes(Configuracion.getConnectionString);
            DataSet DSPacientes;

            try
            {
                DSPacientes = logica.ListarPacientes(condicion, orden);
                grdVistaPacientes.DataSource = DSPacientes;
                grdVistaPacientes.DataMember = DSPacientes.Tables["PACIENTES"].TableName;
            }
            catch (Exception)
            {

                MessageBox.Show("Ocurrió un error", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }//Fin CargarListaPacientes

        //Cuando carga el formulario que cargue la vista de la tabla
        private void frmBuscarPacientes_Load(object sender, EventArgs e)
        {
            try
            {
                CargarListaPacientes();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }//Fin frmBuscarPacientes_Load

        //Filtra la información del Grid cunado se da click a buscar
        private void btnBuscar_Click(object sender, EventArgs e)
        {
            string condicion = string.Empty;

            try
            {
                if (!string.IsNullOrEmpty(txtCedula.Text))
                {
                    condicion = string.Format("NUM_CEDULA like '%{0}%'", txtCedula.Text.Trim()); 
                    //Trim quita los espacios en blanco, busca los que empiecen con el mismo num que ingreso
                }
                else
                {
                    MessageBox.Show("Debe escribir el número de cédula del paciente a buscar", "Atencion", MessageBoxButtons.OK, MessageBoxIcon.Question);
                    txtCedula.Focus();
                }
                CargarListaPacientes(condicion);
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }//Fin btnBuscar_Click

        //Selecciona toda la fila del dato buscado
        private void seleccionar()
        {
            vgn_idCliente = (int)grdVistaPacientes.SelectedRows[0].Cells[0].Value;
            if (grdVistaPacientes.SelectedRows.Count > 0) //Ya seleccionó una
            {
                Aceptar(vgn_idCliente, null);
                Close();
            }
        }//Fin seleccionar

        //Cuando selecciona el elemento del grid
        private void grdVistaPacientes_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            seleccionar();
        }//Fin grdVistaPacientes_CellContentClick

        //Cuando selecciona el boton aceptar
        private void btnAceptar_Click(object sender, EventArgs e)
        {
            seleccionar();
        }//Fin btnAceptar_Click

        //Cierra el formulario
        private void btnCancelar_Click(object sender, EventArgs e)
        {
            Close();
        }//Fin btnCancelar_Click

        //Busca mistras se escribe
        private void txtCedula_KeyPress(object sender, KeyPressEventArgs e)
        {
            string condicion = string.Empty;
            ValidarSoloNum(sender, e);
            try
            {
                if (!string.IsNullOrEmpty(txtCedula.Text))
                {
                    condicion = string.Format("NUM_CEDULA like '%{0}%'", txtCedula.Text.Trim());
                    //Trim quita los espacios en blanco, busca los que empiecen con el mismo num que ingreso
                }
                CargarListaPacientes(condicion);
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
        }//Fin txtCedula_KeyPress

        //Cancela el evento cuando se ingresan letras o simbolos, valida solo numeros
        public void ValidarSoloNum(object sender, KeyPressEventArgs e)
        {
            if (char.IsDigit(e.KeyChar) || e.KeyChar == 8)//TECLAS: NUMEROS Y BORRAR
            {
                //NO SE CANCELA EL EVENTO
                e.Handled = false;
            }
            else
            {
                //CANCELA EL EVENTO
                e.Handled = true;
            }
        }//Fin ValidarSoloNum

    }//Fin clase frmBuscarPacientes : Form
}//Fin namespace
