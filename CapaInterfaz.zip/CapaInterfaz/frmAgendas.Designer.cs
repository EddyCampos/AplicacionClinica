﻿namespace CapaInterfaz
{
    partial class frmAgendas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.cboDias = new System.Windows.Forms.ComboBox();
            this.txtHSalida = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtHEntrada = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtIdMedico = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnLimpiar = new System.Windows.Forms.Button();
            this.btnSalir = new System.Windows.Forms.Button();
            this.btnEliminar = new System.Windows.Forms.Button();
            this.grdVistaAgendas = new System.Windows.Forms.DataGridView();
            this.idAgenda = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idMedico = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dia = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.horaEntrada = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.horaSalida = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnGuardarAgenda = new System.Windows.Forms.Button();
            this.label13 = new System.Windows.Forms.Label();
            this.txtIdAgenda = new System.Windows.Forms.TextBox();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdVistaAgendas)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.cboDias);
            this.groupBox2.Controls.Add(this.txtHSalida);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.txtHEntrada);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.txtIdMedico);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.btnLimpiar);
            this.groupBox2.Controls.Add(this.btnSalir);
            this.groupBox2.Controls.Add(this.btnEliminar);
            this.groupBox2.Controls.Add(this.grdVistaAgendas);
            this.groupBox2.Controls.Add(this.btnGuardarAgenda);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.txtIdAgenda);
            this.groupBox2.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.groupBox2.Location = new System.Drawing.Point(30, 24);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(885, 760);
            this.groupBox2.TabIndex = 41;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Médico";
            // 
            // cboDias
            // 
            this.cboDias.FormattingEnabled = true;
            this.cboDias.Items.AddRange(new object[] {
            "LUNES",
            "MARTES",
            "MIERCOLES",
            "JUEVES",
            "VIERNES"});
            this.cboDias.Location = new System.Drawing.Point(274, 194);
            this.cboDias.Name = "cboDias";
            this.cboDias.Size = new System.Drawing.Size(257, 38);
            this.cboDias.TabIndex = 53;
            // 
            // txtHSalida
            // 
            this.txtHSalida.Location = new System.Drawing.Point(274, 331);
            this.txtHSalida.Name = "txtHSalida";
            this.txtHSalida.Size = new System.Drawing.Size(257, 37);
            this.txtHSalida.TabIndex = 52;
            this.txtHSalida.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtHSalida_KeyPress);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(35, 334);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(147, 30);
            this.label4.TabIndex = 51;
            this.label4.Text = "Hora Salida";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(35, 266);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(166, 30);
            this.label3.TabIndex = 50;
            this.label3.Text = "Hora Entrada";
            // 
            // txtHEntrada
            // 
            this.txtHEntrada.Location = new System.Drawing.Point(274, 259);
            this.txtHEntrada.Name = "txtHEntrada";
            this.txtHEntrada.Size = new System.Drawing.Size(257, 37);
            this.txtHEntrada.TabIndex = 49;
            this.txtHEntrada.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtHEntrada_KeyPress);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(35, 197);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 30);
            this.label2.TabIndex = 47;
            this.label2.Text = "Día";
            // 
            // txtIdMedico
            // 
            this.txtIdMedico.Location = new System.Drawing.Point(274, 122);
            this.txtIdMedico.Name = "txtIdMedico";
            this.txtIdMedico.Size = new System.Drawing.Size(257, 37);
            this.txtIdMedico.TabIndex = 46;
            this.txtIdMedico.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtIdMedico_KeyPress);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(35, 125);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(137, 30);
            this.label1.TabIndex = 45;
            this.label1.Text = "ID Médico";
            // 
            // btnLimpiar
            // 
            this.btnLimpiar.Location = new System.Drawing.Point(634, 682);
            this.btnLimpiar.Name = "btnLimpiar";
            this.btnLimpiar.Size = new System.Drawing.Size(169, 49);
            this.btnLimpiar.TabIndex = 44;
            this.btnLimpiar.Text = "Limpiar";
            this.btnLimpiar.UseVisualStyleBackColor = true;
            this.btnLimpiar.Click += new System.EventHandler(this.btnLimpiar_Click);
            // 
            // btnSalir
            // 
            this.btnSalir.Location = new System.Drawing.Point(449, 682);
            this.btnSalir.Name = "btnSalir";
            this.btnSalir.Size = new System.Drawing.Size(166, 49);
            this.btnSalir.TabIndex = 43;
            this.btnSalir.Text = "Salir";
            this.btnSalir.UseVisualStyleBackColor = true;
            this.btnSalir.Click += new System.EventHandler(this.btnSalir_Click);
            // 
            // btnEliminar
            // 
            this.btnEliminar.Location = new System.Drawing.Point(263, 682);
            this.btnEliminar.Name = "btnEliminar";
            this.btnEliminar.Size = new System.Drawing.Size(166, 49);
            this.btnEliminar.TabIndex = 42;
            this.btnEliminar.Text = "Eliminar";
            this.btnEliminar.UseVisualStyleBackColor = true;
            // 
            // grdVistaAgendas
            // 
            this.grdVistaAgendas.AllowUserToAddRows = false;
            this.grdVistaAgendas.AllowUserToDeleteRows = false;
            this.grdVistaAgendas.AllowUserToResizeColumns = false;
            this.grdVistaAgendas.AllowUserToResizeRows = false;
            this.grdVistaAgendas.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grdVistaAgendas.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idAgenda,
            this.idMedico,
            this.dia,
            this.horaEntrada,
            this.horaSalida});
            this.grdVistaAgendas.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.grdVistaAgendas.Location = new System.Drawing.Point(35, 403);
            this.grdVistaAgendas.Name = "grdVistaAgendas";
            this.grdVistaAgendas.RowHeadersWidth = 62;
            this.grdVistaAgendas.RowTemplate.Height = 33;
            this.grdVistaAgendas.Size = new System.Drawing.Size(816, 247);
            this.grdVistaAgendas.TabIndex = 41;
            // 
            // idAgenda
            // 
            this.idAgenda.DataPropertyName = "ID_AGENDA";
            this.idAgenda.HeaderText = "ID";
            this.idAgenda.MinimumWidth = 8;
            this.idAgenda.Name = "idAgenda";
            this.idAgenda.Width = 150;
            // 
            // idMedico
            // 
            this.idMedico.DataPropertyName = "ID_MEDICO";
            this.idMedico.HeaderText = "ID Médico";
            this.idMedico.MinimumWidth = 8;
            this.idMedico.Name = "idMedico";
            this.idMedico.Width = 150;
            // 
            // dia
            // 
            this.dia.DataPropertyName = "DIA";
            this.dia.HeaderText = "Dia";
            this.dia.MinimumWidth = 8;
            this.dia.Name = "dia";
            this.dia.Width = 150;
            // 
            // horaEntrada
            // 
            this.horaEntrada.DataPropertyName = "HORA_ENTRADA";
            this.horaEntrada.HeaderText = "Hora Entrada";
            this.horaEntrada.MinimumWidth = 8;
            this.horaEntrada.Name = "horaEntrada";
            this.horaEntrada.Width = 150;
            // 
            // horaSalida
            // 
            this.horaSalida.DataPropertyName = "HORA_SALIDA";
            this.horaSalida.HeaderText = "Hora Salida";
            this.horaSalida.MinimumWidth = 8;
            this.horaSalida.Name = "horaSalida";
            this.horaSalida.Width = 150;
            // 
            // btnGuardarAgenda
            // 
            this.btnGuardarAgenda.Location = new System.Drawing.Point(76, 682);
            this.btnGuardarAgenda.Name = "btnGuardarAgenda";
            this.btnGuardarAgenda.Size = new System.Drawing.Size(166, 49);
            this.btnGuardarAgenda.TabIndex = 40;
            this.btnGuardarAgenda.Text = "Guardar";
            this.btnGuardarAgenda.UseVisualStyleBackColor = true;
            this.btnGuardarAgenda.Click += new System.EventHandler(this.btnGuardarAgenda_Click);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(35, 64);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(140, 30);
            this.label13.TabIndex = 38;
            this.label13.Text = "ID Agenda";
            // 
            // txtIdAgenda
            // 
            this.txtIdAgenda.Enabled = false;
            this.txtIdAgenda.Location = new System.Drawing.Point(274, 57);
            this.txtIdAgenda.Name = "txtIdAgenda";
            this.txtIdAgenda.Size = new System.Drawing.Size(257, 37);
            this.txtIdAgenda.TabIndex = 39;
            // 
            // frmAgendas
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(946, 808);
            this.Controls.Add(this.groupBox2);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmAgendas";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmAgendas";
            this.Load += new System.EventHandler(this.frmAgendas_Load);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdVistaAgendas)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txtHSalida;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtHEntrada;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtIdMedico;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnLimpiar;
        private System.Windows.Forms.Button btnSalir;
        private System.Windows.Forms.Button btnEliminar;
        private System.Windows.Forms.DataGridView grdVistaAgendas;
        private System.Windows.Forms.Button btnGuardarAgenda;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtIdAgenda;
        private System.Windows.Forms.DataGridViewTextBoxColumn idAgenda;
        private System.Windows.Forms.DataGridViewTextBoxColumn idMedico;
        private System.Windows.Forms.DataGridViewTextBoxColumn dia;
        private System.Windows.Forms.DataGridViewTextBoxColumn horaEntrada;
        private System.Windows.Forms.DataGridViewTextBoxColumn horaSalida;
        private System.Windows.Forms.ComboBox cboDias;
    }
}