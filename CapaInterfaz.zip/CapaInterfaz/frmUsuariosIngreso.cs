﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using CapaEntidades;
using CapaLogica;

namespace CapaInterfaz
{
    public partial class frmUsuariosIngreso : Form
    {
        public frmUsuariosIngreso()
        {
            InitializeComponent();
        }

        //Boton limpia todas las casillas
        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            limpiar();
        }//Fin btnLimpiar_Click

        //Cierra el formulario
        private void btnSalir_Click(object sender, EventArgs e)
        {
            Close();
        }//Fin btnSalir_Click

        //Genera Entidad
        private EntidadUsuarioIngresos GenerarEntidadUsuarios()
        {
            EntidadUsuarioIngresos usuario = new EntidadUsuarioIngresos();

            usuario.SetIdPaciente(Convert.ToInt32(txtIdPaciente.Text));
            usuario.SetCorreoElectronico(txtCorreo.Text);
            usuario.SetContrasena(txtContrasena.Text);

            return usuario;
        }//Fin GenerarEntidadUsuarios

        //Guarda en la base de datos
        private void btnGuardarUsuario_Click(object sender, EventArgs e)
        {
            BLUsuariosIngresos logica = new BLUsuariosIngresos(Configuracion.getConnectionString);

            EntidadUsuarioIngresos usuario;
            int resultado;

            try
            {
                if (!string.IsNullOrEmpty(txtIdPaciente.Text) &&
                    !string.IsNullOrEmpty(txtCorreo.Text) &&
                    !string.IsNullOrEmpty(txtContrasena.Text))
                {
                    usuario = GenerarEntidadUsuarios();
                    resultado = logica.InsertarUsuario(usuario);
                    MessageBox.Show("Usuario insertado Correctamente", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    limpiar();
                    CargarListaUsuarios();
                }
                else
                {
                    MessageBox.Show("Datos obligatorios", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }//Fin btnGuardarUsuario_Click

        //Cargar la lista de clientes con un DATASET
        public void CargarListaUsuarios(string condicion = "", string orden = "")
        {
            BLUsuariosIngresos logica = new BLUsuariosIngresos(Configuracion.getConnectionString);
            DataSet DSUsuarios;

            try
            {
                DSUsuarios = logica.ListarUsuarios(condicion, orden);
                grdVistaUsuarios.DataSource = DSUsuarios;
                grdVistaUsuarios.DataMember = DSUsuarios.Tables["USUARIO_INGRESO"].TableName;
            }
            catch (Exception)
            {

                MessageBox.Show("Ocurrió un error", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }//Fin CargarListaAgenda

        //Cuando carga el formulario que cargue la vista de la tabla
        private void frmUsuariosIngreso_Load(object sender, EventArgs e)
        {
            try
            {
                CargarListaUsuarios();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }//Fin frmUsuariosIngreso_Load

        //Limpia info de los espacios
        private void limpiar()
        {
            txtIdUsuario.Text = string.Empty;
            txtIdPaciente.Text = string.Empty;
            txtCorreo.Text = string.Empty;
            txtContrasena.Text = string.Empty;
        }//Fin limpiar

        //Cancela el evento cuando se ingresan letras o simbolos, valida solo numeros
        public void ValidarSoloNum(object sender, KeyPressEventArgs e)
        {
            if (char.IsDigit(e.KeyChar) || e.KeyChar == 8)//TECLAS: NUMEROS Y BORRAR
            {
                //NO SE CANCELA EL EVENTO
                e.Handled = false;
            }
            else
            {
                //CANCELA EL EVENTO
                e.Handled = true;
            }
        }//Fin ValidarSoloNum

        //Solo permite llenar el campo con numeros
        private void txtIdPaciente_KeyPress(object sender, KeyPressEventArgs e)
        {
            ValidarSoloNum(sender, e);
        }
    }//Fin clase frmUsuariosIngreso : Form
}//Fin namespace
