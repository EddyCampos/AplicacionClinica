﻿namespace CapaInterfaz
{
    partial class frmExpedientes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.dtpFCreacion = new System.Windows.Forms.DateTimePicker();
            this.label2 = new System.Windows.Forms.Label();
            this.txtIdPaciente = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnLimpiar = new System.Windows.Forms.Button();
            this.btnSalir = new System.Windows.Forms.Button();
            this.btnEliminar = new System.Windows.Forms.Button();
            this.grdVistaExpedientes = new System.Windows.Forms.DataGridView();
            this.ID_SECRETARIO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idPaciente = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fCreacion = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnGuardarExpediente = new System.Windows.Forms.Button();
            this.label13 = new System.Windows.Forms.Label();
            this.txtIdExpediente = new System.Windows.Forms.TextBox();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdVistaExpedientes)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.dtpFCreacion);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.txtIdPaciente);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.btnLimpiar);
            this.groupBox2.Controls.Add(this.btnSalir);
            this.groupBox2.Controls.Add(this.btnEliminar);
            this.groupBox2.Controls.Add(this.grdVistaExpedientes);
            this.groupBox2.Controls.Add(this.btnGuardarExpediente);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.txtIdExpediente);
            this.groupBox2.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.groupBox2.Location = new System.Drawing.Point(33, 27);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(827, 613);
            this.groupBox2.TabIndex = 42;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Expediente";
            // 
            // dtpFCreacion
            // 
            this.dtpFCreacion.Location = new System.Drawing.Point(274, 190);
            this.dtpFCreacion.Name = "dtpFCreacion";
            this.dtpFCreacion.Size = new System.Drawing.Size(257, 37);
            this.dtpFCreacion.TabIndex = 48;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(35, 197);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(207, 30);
            this.label2.TabIndex = 47;
            this.label2.Text = "Fecha Creación";
            // 
            // txtIdPaciente
            // 
            this.txtIdPaciente.Location = new System.Drawing.Point(274, 122);
            this.txtIdPaciente.Name = "txtIdPaciente";
            this.txtIdPaciente.Size = new System.Drawing.Size(257, 37);
            this.txtIdPaciente.TabIndex = 46;
            this.txtIdPaciente.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtIdPaciente_KeyPress);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(35, 129);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(151, 30);
            this.label1.TabIndex = 45;
            this.label1.Text = "ID Paciente";
            // 
            // btnLimpiar
            // 
            this.btnLimpiar.Location = new System.Drawing.Point(608, 545);
            this.btnLimpiar.Name = "btnLimpiar";
            this.btnLimpiar.Size = new System.Drawing.Size(169, 49);
            this.btnLimpiar.TabIndex = 44;
            this.btnLimpiar.Text = "Limpiar";
            this.btnLimpiar.UseVisualStyleBackColor = true;
            this.btnLimpiar.Click += new System.EventHandler(this.btnLimpiar_Click);
            // 
            // btnSalir
            // 
            this.btnSalir.Location = new System.Drawing.Point(423, 545);
            this.btnSalir.Name = "btnSalir";
            this.btnSalir.Size = new System.Drawing.Size(166, 49);
            this.btnSalir.TabIndex = 43;
            this.btnSalir.Text = "Salir";
            this.btnSalir.UseVisualStyleBackColor = true;
            this.btnSalir.Click += new System.EventHandler(this.btnSalir_Click);
            // 
            // btnEliminar
            // 
            this.btnEliminar.Location = new System.Drawing.Point(237, 545);
            this.btnEliminar.Name = "btnEliminar";
            this.btnEliminar.Size = new System.Drawing.Size(166, 49);
            this.btnEliminar.TabIndex = 42;
            this.btnEliminar.Text = "Eliminar";
            this.btnEliminar.UseVisualStyleBackColor = true;
            // 
            // grdVistaExpedientes
            // 
            this.grdVistaExpedientes.AllowUserToAddRows = false;
            this.grdVistaExpedientes.AllowUserToDeleteRows = false;
            this.grdVistaExpedientes.AllowUserToResizeColumns = false;
            this.grdVistaExpedientes.AllowUserToResizeRows = false;
            this.grdVistaExpedientes.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grdVistaExpedientes.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ID_SECRETARIO,
            this.idPaciente,
            this.fCreacion});
            this.grdVistaExpedientes.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.grdVistaExpedientes.Location = new System.Drawing.Point(35, 270);
            this.grdVistaExpedientes.Name = "grdVistaExpedientes";
            this.grdVistaExpedientes.RowHeadersWidth = 62;
            this.grdVistaExpedientes.RowTemplate.Height = 33;
            this.grdVistaExpedientes.Size = new System.Drawing.Size(757, 247);
            this.grdVistaExpedientes.TabIndex = 41;
            // 
            // ID_SECRETARIO
            // 
            this.ID_SECRETARIO.DataPropertyName = "ID_EXPEDIENTE";
            this.ID_SECRETARIO.HeaderText = "ID";
            this.ID_SECRETARIO.MinimumWidth = 8;
            this.ID_SECRETARIO.Name = "ID_SECRETARIO";
            this.ID_SECRETARIO.ReadOnly = true;
            this.ID_SECRETARIO.Width = 150;
            // 
            // idPaciente
            // 
            this.idPaciente.DataPropertyName = "ID_PACIENTE";
            this.idPaciente.HeaderText = "ID Paciente";
            this.idPaciente.MinimumWidth = 8;
            this.idPaciente.Name = "idPaciente";
            this.idPaciente.Width = 150;
            // 
            // fCreacion
            // 
            this.fCreacion.DataPropertyName = "FECHA_CREACION";
            this.fCreacion.HeaderText = "Fecha Creación";
            this.fCreacion.MinimumWidth = 8;
            this.fCreacion.Name = "fCreacion";
            this.fCreacion.Width = 150;
            // 
            // btnGuardarExpediente
            // 
            this.btnGuardarExpediente.Location = new System.Drawing.Point(50, 545);
            this.btnGuardarExpediente.Name = "btnGuardarExpediente";
            this.btnGuardarExpediente.Size = new System.Drawing.Size(166, 49);
            this.btnGuardarExpediente.TabIndex = 40;
            this.btnGuardarExpediente.Text = "Guardar";
            this.btnGuardarExpediente.UseVisualStyleBackColor = true;
            this.btnGuardarExpediente.Click += new System.EventHandler(this.btnGuardarExpediente_Click);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(35, 64);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(178, 30);
            this.label13.TabIndex = 38;
            this.label13.Text = "ID Expediente";
            // 
            // txtIdExpediente
            // 
            this.txtIdExpediente.Enabled = false;
            this.txtIdExpediente.Location = new System.Drawing.Point(274, 57);
            this.txtIdExpediente.Name = "txtIdExpediente";
            this.txtIdExpediente.Size = new System.Drawing.Size(257, 37);
            this.txtIdExpediente.TabIndex = 39;
            // 
            // frmExpedientes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(892, 672);
            this.Controls.Add(this.groupBox2);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmExpedientes";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Expedientes";
            this.Load += new System.EventHandler(this.frmExpedientes_Load);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdVistaExpedientes)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.DateTimePicker dtpFCreacion;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtIdPaciente;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnLimpiar;
        private System.Windows.Forms.Button btnSalir;
        private System.Windows.Forms.Button btnEliminar;
        private System.Windows.Forms.DataGridView grdVistaExpedientes;
        private System.Windows.Forms.Button btnGuardarExpediente;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtIdExpediente;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID_SECRETARIO;
        private System.Windows.Forms.DataGridViewTextBoxColumn idPaciente;
        private System.Windows.Forms.DataGridViewTextBoxColumn fCreacion;
    }
}