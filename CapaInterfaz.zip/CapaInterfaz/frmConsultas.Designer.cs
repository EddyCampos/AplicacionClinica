﻿namespace CapaInterfaz
{
    partial class frmConsultas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.dtpFecha = new System.Windows.Forms.DateTimePicker();
            this.txtIdPaciente = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtMotivo = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtHora = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtIdMedico = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnLimpiar = new System.Windows.Forms.Button();
            this.btnSalir = new System.Windows.Forms.Button();
            this.btnEliminar = new System.Windows.Forms.Button();
            this.grdVistaConsultas = new System.Windows.Forms.DataGridView();
            this.idConsulta = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idMedico = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idPaciente = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dia = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.hora = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.motivo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnGuardarConsulta = new System.Windows.Forms.Button();
            this.label13 = new System.Windows.Forms.Label();
            this.txtIdConsulta = new System.Windows.Forms.TextBox();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdVistaConsultas)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.dtpFecha);
            this.groupBox2.Controls.Add(this.txtIdPaciente);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.txtMotivo);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.txtHora);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.txtIdMedico);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.btnLimpiar);
            this.groupBox2.Controls.Add(this.btnSalir);
            this.groupBox2.Controls.Add(this.btnEliminar);
            this.groupBox2.Controls.Add(this.grdVistaConsultas);
            this.groupBox2.Controls.Add(this.btnGuardarConsulta);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.txtIdConsulta);
            this.groupBox2.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.groupBox2.Location = new System.Drawing.Point(32, 31);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(885, 817);
            this.groupBox2.TabIndex = 42;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Médico";
            // 
            // dtpFecha
            // 
            this.dtpFecha.Location = new System.Drawing.Point(274, 258);
            this.dtpFecha.Name = "dtpFecha";
            this.dtpFecha.Size = new System.Drawing.Size(257, 37);
            this.dtpFecha.TabIndex = 56;
            // 
            // txtIdPaciente
            // 
            this.txtIdPaciente.Location = new System.Drawing.Point(274, 191);
            this.txtIdPaciente.Name = "txtIdPaciente";
            this.txtIdPaciente.Size = new System.Drawing.Size(257, 37);
            this.txtIdPaciente.TabIndex = 55;
            this.txtIdPaciente.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtIdPaciente_KeyPress);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(35, 198);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(151, 30);
            this.label5.TabIndex = 54;
            this.label5.Text = "ID Paciente";
            // 
            // txtMotivo
            // 
            this.txtMotivo.Location = new System.Drawing.Point(274, 399);
            this.txtMotivo.Name = "txtMotivo";
            this.txtMotivo.Size = new System.Drawing.Size(257, 37);
            this.txtMotivo.TabIndex = 52;
            this.txtMotivo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtMotivo_KeyPress);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(35, 402);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(97, 30);
            this.label4.TabIndex = 51;
            this.label4.Text = "Motivo";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(35, 334);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(68, 30);
            this.label3.TabIndex = 50;
            this.label3.Text = "Hora";
            // 
            // txtHora
            // 
            this.txtHora.Location = new System.Drawing.Point(274, 327);
            this.txtHora.Name = "txtHora";
            this.txtHora.Size = new System.Drawing.Size(257, 37);
            this.txtHora.TabIndex = 49;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(35, 265);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 30);
            this.label2.TabIndex = 47;
            this.label2.Text = "Día";
            // 
            // txtIdMedico
            // 
            this.txtIdMedico.Location = new System.Drawing.Point(274, 122);
            this.txtIdMedico.Name = "txtIdMedico";
            this.txtIdMedico.Size = new System.Drawing.Size(257, 37);
            this.txtIdMedico.TabIndex = 46;
            this.txtIdMedico.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtIdMedico_KeyPress);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(35, 125);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(137, 30);
            this.label1.TabIndex = 45;
            this.label1.Text = "ID Médico";
            // 
            // btnLimpiar
            // 
            this.btnLimpiar.Location = new System.Drawing.Point(631, 743);
            this.btnLimpiar.Name = "btnLimpiar";
            this.btnLimpiar.Size = new System.Drawing.Size(169, 49);
            this.btnLimpiar.TabIndex = 44;
            this.btnLimpiar.Text = "Limpiar";
            this.btnLimpiar.UseVisualStyleBackColor = true;
            this.btnLimpiar.Click += new System.EventHandler(this.btnLimpiar_Click);
            // 
            // btnSalir
            // 
            this.btnSalir.Location = new System.Drawing.Point(446, 743);
            this.btnSalir.Name = "btnSalir";
            this.btnSalir.Size = new System.Drawing.Size(166, 49);
            this.btnSalir.TabIndex = 43;
            this.btnSalir.Text = "Salir";
            this.btnSalir.UseVisualStyleBackColor = true;
            this.btnSalir.Click += new System.EventHandler(this.btnSalir_Click);
            // 
            // btnEliminar
            // 
            this.btnEliminar.Location = new System.Drawing.Point(260, 743);
            this.btnEliminar.Name = "btnEliminar";
            this.btnEliminar.Size = new System.Drawing.Size(166, 49);
            this.btnEliminar.TabIndex = 42;
            this.btnEliminar.Text = "Eliminar";
            this.btnEliminar.UseVisualStyleBackColor = true;
            // 
            // grdVistaConsultas
            // 
            this.grdVistaConsultas.AllowUserToAddRows = false;
            this.grdVistaConsultas.AllowUserToDeleteRows = false;
            this.grdVistaConsultas.AllowUserToResizeColumns = false;
            this.grdVistaConsultas.AllowUserToResizeRows = false;
            this.grdVistaConsultas.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grdVistaConsultas.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idConsulta,
            this.idMedico,
            this.idPaciente,
            this.dia,
            this.hora,
            this.motivo});
            this.grdVistaConsultas.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.grdVistaConsultas.Location = new System.Drawing.Point(35, 475);
            this.grdVistaConsultas.Name = "grdVistaConsultas";
            this.grdVistaConsultas.RowHeadersWidth = 62;
            this.grdVistaConsultas.RowTemplate.Height = 33;
            this.grdVistaConsultas.Size = new System.Drawing.Size(816, 247);
            this.grdVistaConsultas.TabIndex = 41;
            // 
            // idConsulta
            // 
            this.idConsulta.DataPropertyName = "ID_CONSULTA";
            this.idConsulta.HeaderText = "ID";
            this.idConsulta.MinimumWidth = 8;
            this.idConsulta.Name = "idConsulta";
            this.idConsulta.Width = 150;
            // 
            // idMedico
            // 
            this.idMedico.DataPropertyName = "ID_MEDICO";
            this.idMedico.HeaderText = "ID Médico";
            this.idMedico.MinimumWidth = 8;
            this.idMedico.Name = "idMedico";
            this.idMedico.Width = 150;
            // 
            // idPaciente
            // 
            this.idPaciente.DataPropertyName = "ID_PACIENTE";
            this.idPaciente.HeaderText = "ID Paciente";
            this.idPaciente.MinimumWidth = 8;
            this.idPaciente.Name = "idPaciente";
            this.idPaciente.Width = 150;
            // 
            // dia
            // 
            this.dia.DataPropertyName = "DIA";
            this.dia.HeaderText = "Dia";
            this.dia.MinimumWidth = 8;
            this.dia.Name = "dia";
            this.dia.Width = 150;
            // 
            // hora
            // 
            this.hora.DataPropertyName = "HORA";
            this.hora.HeaderText = "Hora";
            this.hora.MinimumWidth = 8;
            this.hora.Name = "hora";
            this.hora.Width = 150;
            // 
            // motivo
            // 
            this.motivo.DataPropertyName = "MOTIVO";
            this.motivo.HeaderText = "Motivo";
            this.motivo.MinimumWidth = 8;
            this.motivo.Name = "motivo";
            this.motivo.Width = 150;
            // 
            // btnGuardarConsulta
            // 
            this.btnGuardarConsulta.Location = new System.Drawing.Point(73, 743);
            this.btnGuardarConsulta.Name = "btnGuardarConsulta";
            this.btnGuardarConsulta.Size = new System.Drawing.Size(166, 49);
            this.btnGuardarConsulta.TabIndex = 40;
            this.btnGuardarConsulta.Text = "Guardar";
            this.btnGuardarConsulta.UseVisualStyleBackColor = true;
            this.btnGuardarConsulta.Click += new System.EventHandler(this.btnGuardarConsulta_Click);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(35, 64);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(37, 30);
            this.label13.TabIndex = 38;
            this.label13.Text = "ID";
            // 
            // txtIdConsulta
            // 
            this.txtIdConsulta.Enabled = false;
            this.txtIdConsulta.Location = new System.Drawing.Point(274, 57);
            this.txtIdConsulta.Name = "txtIdConsulta";
            this.txtIdConsulta.Size = new System.Drawing.Size(257, 37);
            this.txtIdConsulta.TabIndex = 39;
            // 
            // frmConsultas
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(949, 875);
            this.Controls.Add(this.groupBox2);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmConsultas";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Consultas";
            this.Load += new System.EventHandler(this.frmConsultas_Load);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdVistaConsultas)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txtMotivo;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtHora;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtIdMedico;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnLimpiar;
        private System.Windows.Forms.Button btnSalir;
        private System.Windows.Forms.Button btnEliminar;
        private System.Windows.Forms.DataGridView grdVistaConsultas;
        private System.Windows.Forms.Button btnGuardarConsulta;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtIdConsulta;
        private System.Windows.Forms.TextBox txtIdPaciente;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DataGridViewTextBoxColumn idConsulta;
        private System.Windows.Forms.DataGridViewTextBoxColumn idMedico;
        private System.Windows.Forms.DataGridViewTextBoxColumn idPaciente;
        private System.Windows.Forms.DataGridViewTextBoxColumn dia;
        private System.Windows.Forms.DataGridViewTextBoxColumn hora;
        private System.Windows.Forms.DataGridViewTextBoxColumn motivo;
        private System.Windows.Forms.DateTimePicker dtpFecha;
    }
}