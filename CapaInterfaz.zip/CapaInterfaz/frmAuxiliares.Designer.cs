﻿namespace CapaInterfaz
{
    partial class frmAuxiliares
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txtArea = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtIdEmpleado = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnLimpiar = new System.Windows.Forms.Button();
            this.btnSalir = new System.Windows.Forms.Button();
            this.btnEliminar = new System.Windows.Forms.Button();
            this.grdVistaAuxiliares = new System.Windows.Forms.DataGridView();
            this.ID_SECRETARIO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idEmpleado = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.area = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnGuardarAuxiliar = new System.Windows.Forms.Button();
            this.label13 = new System.Windows.Forms.Label();
            this.txtIdAuxiliar = new System.Windows.Forms.TextBox();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdVistaAuxiliares)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.txtArea);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.txtIdEmpleado);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.btnLimpiar);
            this.groupBox2.Controls.Add(this.btnSalir);
            this.groupBox2.Controls.Add(this.btnEliminar);
            this.groupBox2.Controls.Add(this.grdVistaAuxiliares);
            this.groupBox2.Controls.Add(this.btnGuardarAuxiliar);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.txtIdAuxiliar);
            this.groupBox2.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.groupBox2.Location = new System.Drawing.Point(30, 26);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(827, 613);
            this.groupBox2.TabIndex = 41;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Auxiliar";
            // 
            // txtArea
            // 
            this.txtArea.Location = new System.Drawing.Point(274, 190);
            this.txtArea.Name = "txtArea";
            this.txtArea.Size = new System.Drawing.Size(257, 37);
            this.txtArea.TabIndex = 48;
            this.txtArea.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtArea_KeyPress);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(35, 197);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(69, 30);
            this.label2.TabIndex = 47;
            this.label2.Text = "Area";
            // 
            // txtIdEmpleado
            // 
            this.txtIdEmpleado.Location = new System.Drawing.Point(274, 122);
            this.txtIdEmpleado.Name = "txtIdEmpleado";
            this.txtIdEmpleado.Size = new System.Drawing.Size(257, 37);
            this.txtIdEmpleado.TabIndex = 46;
            this.txtIdEmpleado.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtIdEmpleado_KeyPress);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(35, 125);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(167, 30);
            this.label1.TabIndex = 45;
            this.label1.Text = "ID Empleado";
            // 
            // btnLimpiar
            // 
            this.btnLimpiar.Location = new System.Drawing.Point(608, 545);
            this.btnLimpiar.Name = "btnLimpiar";
            this.btnLimpiar.Size = new System.Drawing.Size(169, 49);
            this.btnLimpiar.TabIndex = 44;
            this.btnLimpiar.Text = "Limpiar";
            this.btnLimpiar.UseVisualStyleBackColor = true;
            this.btnLimpiar.Click += new System.EventHandler(this.btnLimpiar_Click);
            // 
            // btnSalir
            // 
            this.btnSalir.Location = new System.Drawing.Point(423, 545);
            this.btnSalir.Name = "btnSalir";
            this.btnSalir.Size = new System.Drawing.Size(166, 49);
            this.btnSalir.TabIndex = 43;
            this.btnSalir.Text = "Salir";
            this.btnSalir.UseVisualStyleBackColor = true;
            this.btnSalir.Click += new System.EventHandler(this.btnSalir_Click);
            // 
            // btnEliminar
            // 
            this.btnEliminar.Location = new System.Drawing.Point(237, 545);
            this.btnEliminar.Name = "btnEliminar";
            this.btnEliminar.Size = new System.Drawing.Size(166, 49);
            this.btnEliminar.TabIndex = 42;
            this.btnEliminar.Text = "Eliminar";
            this.btnEliminar.UseVisualStyleBackColor = true;
            // 
            // grdVistaAuxiliares
            // 
            this.grdVistaAuxiliares.AllowUserToAddRows = false;
            this.grdVistaAuxiliares.AllowUserToDeleteRows = false;
            this.grdVistaAuxiliares.AllowUserToResizeColumns = false;
            this.grdVistaAuxiliares.AllowUserToResizeRows = false;
            this.grdVistaAuxiliares.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grdVistaAuxiliares.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ID_SECRETARIO,
            this.idEmpleado,
            this.area});
            this.grdVistaAuxiliares.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.grdVistaAuxiliares.Location = new System.Drawing.Point(35, 270);
            this.grdVistaAuxiliares.Name = "grdVistaAuxiliares";
            this.grdVistaAuxiliares.RowHeadersWidth = 62;
            this.grdVistaAuxiliares.RowTemplate.Height = 33;
            this.grdVistaAuxiliares.Size = new System.Drawing.Size(757, 247);
            this.grdVistaAuxiliares.TabIndex = 41;
            // 
            // ID_SECRETARIO
            // 
            this.ID_SECRETARIO.DataPropertyName = "ID_AUXILIAR";
            this.ID_SECRETARIO.HeaderText = "ID";
            this.ID_SECRETARIO.MinimumWidth = 8;
            this.ID_SECRETARIO.Name = "ID_SECRETARIO";
            this.ID_SECRETARIO.ReadOnly = true;
            this.ID_SECRETARIO.Width = 150;
            // 
            // idEmpleado
            // 
            this.idEmpleado.DataPropertyName = "ID_EMPLEADO";
            this.idEmpleado.HeaderText = "ID Empleado";
            this.idEmpleado.MinimumWidth = 8;
            this.idEmpleado.Name = "idEmpleado";
            this.idEmpleado.Width = 200;
            // 
            // area
            // 
            this.area.DataPropertyName = "AREA";
            this.area.HeaderText = "Area";
            this.area.MinimumWidth = 8;
            this.area.Name = "area";
            this.area.Width = 320;
            // 
            // btnGuardarAuxiliar
            // 
            this.btnGuardarAuxiliar.Location = new System.Drawing.Point(50, 545);
            this.btnGuardarAuxiliar.Name = "btnGuardarAuxiliar";
            this.btnGuardarAuxiliar.Size = new System.Drawing.Size(166, 49);
            this.btnGuardarAuxiliar.TabIndex = 40;
            this.btnGuardarAuxiliar.Text = "Guardar";
            this.btnGuardarAuxiliar.UseVisualStyleBackColor = true;
            this.btnGuardarAuxiliar.Click += new System.EventHandler(this.btnGuardarAuxiliar_Click);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(35, 64);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(129, 30);
            this.label13.TabIndex = 38;
            this.label13.Text = "ID Auxiliar";
            // 
            // txtIdAuxiliar
            // 
            this.txtIdAuxiliar.Enabled = false;
            this.txtIdAuxiliar.Location = new System.Drawing.Point(274, 57);
            this.txtIdAuxiliar.Name = "txtIdAuxiliar";
            this.txtIdAuxiliar.Size = new System.Drawing.Size(257, 37);
            this.txtIdAuxiliar.TabIndex = 39;
            // 
            // frmAuxiliares
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(889, 678);
            this.Controls.Add(this.groupBox2);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmAuxiliares";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Auxiliares";
            this.Load += new System.EventHandler(this.frmAuxiliares_Load);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdVistaAuxiliares)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txtArea;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtIdEmpleado;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnLimpiar;
        private System.Windows.Forms.Button btnSalir;
        private System.Windows.Forms.Button btnEliminar;
        private System.Windows.Forms.DataGridView grdVistaAuxiliares;
        private System.Windows.Forms.Button btnGuardarAuxiliar;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtIdAuxiliar;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID_SECRETARIO;
        private System.Windows.Forms.DataGridViewTextBoxColumn idEmpleado;
        private System.Windows.Forms.DataGridViewTextBoxColumn area;
    }
}